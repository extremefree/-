"""集中配置：服务端口、MQTT、阈值、生育期配方、协议关键字。"""

# ---------- 服务 ----------
HOST = "0.0.0.0"
PORT = 5000
SECRET_KEY = "dev-secret"
SAMPLE_INTERVAL = 1.0          # 后台巡检间隔(秒)
NUM_CHARTS = 3                 # 监控页折线图数量
NUM_LIST = 6                   # 监控页清单项数
LIST_MIN = 0
LIST_MAX = 100

# ---------- 病害 ----------
DISEASE_NAMES = ["白粉病", "斑褐病", "干腐病", "轮斑病", "炭疽病", "锈病"]

# ---------- MQTT (DFRobot SIoT) ----------
MQTT_SERVER = "192.168.3.56"
MQTT_PORT = 1883
MQTT_USERNAME = "siot"
MQTT_PASSWORD = "dfrobot"
MQTT_TOPIC = "DFRobot/Seifer"
MQTT_TOPIC_BUTTON = "DFRobot/BUTTON"   # 操作日志专用通道 (与业务总线隔离，避免回环混淆)

# ---------- MQTT payload 关键字 (沿用 DFRobot/Seifer, 靠前缀区分) ----------
KW_MOISTURE = "湿度："        # 上行: 湿度：<int 0-100>
KW_TANK = "水箱水位："        # 上行: 水箱水位：<int 0-100>
KW_LAST_WATER = "本次浇水量："  # 上行: 本次浇水量：<int mL>
KW_FRUIT = "结果数量："        # 上行: 结果数量：<int>
KW_DISEASE = "病害："          # 上行: 病害：<1-6>  (累加对应索引)
KW_DISEASE_CLEAR = "病害零："  # 上行: 病害零：<1-6> (清零对应索引)
KW_ACTION_LOG = "操作日志："   # 操作日志：<JSON 操作日志>

KW_PUMP_ON = "水泵：开"        # 下行
KW_PUMP_OFF = "水泵：关"
KW_FERTA_ON = "施肥泵A：开"
KW_FERTA_OFF = "施肥泵A：关"
KW_FERTB_ON = "施肥泵B：开"
KW_FERTB_OFF = "施肥泵B：关"

# ---------- 水肥控制：阈值与安全约束 ----------
MOISTURE_LOW = 40             # %，低于则触发灌溉
MOISTURE_HIGH = 70            # %，高于则停止
MAX_DAILY_WATER = 20000       # mL，单日浇水上限
MIN_INTERVAL = 600            # 秒，两次灌溉最小间隔
MAX_CYCLE_TIME = 120          # 秒，单次灌溉最长
TANK_LOW = 20                 # %，水箱低于告警\
SIM_PH_RANGE = (6.0, 8.0)
SIM_TEMP_RANGE = (20, 30)
SIM_HUMIDITY_RANGE = (60, 80)
SIM_MOISTURE_RANGE = (30, 70)
SIM_EC_RANGE = (1.0, 2.0)
SIM_TANK_RANGE = (50, 100)

# ---------- 仿真回退默认值范围 ----------
DEFAULT_PH = 6.5               # pH/EC 由用户手动输入；未输入前的中性默认值
DEFAULT_EC = 1.5
DEFAULT_ETO_MM = 4.0           # Open-Meteo 取数失败时的回退参考蒸散量 (mm/d, 夏季典型)

# ---------- 农学决策：土壤水分常数 (壤土) ----------
# FC 田间持水量 / PWP 凋萎点 / MAD 允许亏缺 / root_zone 根区深度 / wetted_area 滴头润湿面积
SOIL_PARAMS = {
    "fc": 28.0,                # % VWC
    "pwp": 14.0,               # % VWC
    "mad": 0.5,                # 苹果常用 50%
    "root_depth_mm": 300.0,    # 有效根区深度
    "wetted_area_m2": 0.03,    # 单滴头润湿面积 (演示口径，决定 mL 量级)
}

# 苹果作物系数 Kc (FAO-56) — 与生育期配方对齐
APPLE_KC = {
    "萌芽期": 0.50,
    "花期": 0.70,
    "坐果期": 0.85,
    "膨大期": 0.95,
    "着色成熟期": 0.80,
    "休眠期": 0.45,
}

# ---------- pH / EC 调节阈值 ----------
PH_MIN = 5.5
PH_MAX = 7.5
EC_SALINITY = 2.0              # >此值加 15% 淋洗水量排盐 (苹果 ECe 阈值 ~1.7 dS/m)
EC_LOW = 1.0                   # <此值提示养分偏低
LEACHING_FRACTION = 0.15       # 高 EC 时的额外淋洗比例

# ---------- 天气 / ETo (Open-Meteo, 免费、无需 API key) ----------
OPEN_METEO_GEO_URL = "https://geocoding-api.open-meteo.com/v1/search"
OPEN_METEO_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
DEFAULT_LOCATION = "北京"

# ---------- ollama ----------
OLLAMA_URL = "http://localhost:11434/api/chat"
OLLAMA_MODEL = "qwen2.5:7b"

# ---------- 生育期配方表 ----------
# (N:P:K, A泵秒, B泵秒, 目标量mL, 频率描述)
GROWTH_RECIPES = {
    "萌芽期":   {"months": (2, 3),     "npk": "1:1:1", "a_sec": 10, "b_sec": 10, "volume": 500,  "freq": "2天/次"},
    "花期":     {"months": (3, 4),     "npk": "1:2:2", "a_sec": 8,  "b_sec": 16, "volume": 600,  "freq": "1天/次"},
    "坐果期":   {"months": (5, 5),     "npk": "2:1:2", "a_sec": 16, "b_sec": 16, "volume": 800,  "freq": "1天/次"},
    "膨大期":   {"months": (6, 7),     "npk": "1:1:3", "a_sec": 10, "b_sec": 30, "volume": 1000, "freq": "1天/次"},
    "着色成熟期": {"months": (8, 9),   "npk": "1:1:3", "a_sec": 8,  "b_sec": 24, "volume": 700,  "freq": "2天/次"},
    "休眠期":   {"months": (10, 1),    "npk": "-",    "a_sec": 0,  "b_sec": 0,  "volume": 0,    "freq": "不灌溉"},
}

# ---------- 持久化 ----------
IRRIGATION_LOG_MAX = 200       # data.json 中保留最近多少条灌溉日志
