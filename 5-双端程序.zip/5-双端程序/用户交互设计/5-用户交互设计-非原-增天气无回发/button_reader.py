"""BUTTON 主题阅读器：订阅操作日志专用通道并实时打印。

操作日志由 app.py 在用户按下按钮时发布 (见 action_logger.py)，报文形如：
    操作日志：{"ts":"2026-08-13 12:00:00","event":"pump_cmd","payload":{"state":"on"},"page":"fert"}

用法:
    python button_reader.py                      # 启动时交互输入 broker (回车用默认)
    python button_reader.py --host 192.168.3.56  # 直接指定 broker

Ctrl+C 退出。
"""
import argparse
import json
import random
import time

import paho.mqtt.client as mqtt

import config


def _make_client(client_id):
    """创建 paho client，兼容 1.x 与 2.x (避免 2.x 的 CallbackAPIVersion 弃用告警)。"""
    try:
        return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
    except (AttributeError, TypeError):
        return mqtt.Client(client_id=client_id)


def log(tag, msg):
    print(f"[{time.strftime('%H:%M:%S')}] {tag} {msg}", flush=True)


def main():
    ap = argparse.ArgumentParser(description="订阅 BUTTON 主题，实时查看操作日志")
    ap.add_argument("--host", default=None, help=f"MQTT broker 地址 (默认 {config.MQTT_SERVER})")
    ap.add_argument("--port", type=int, default=config.MQTT_PORT)
    args = ap.parse_args()

    host = args.host
    if host is None:
        try:
            s = input(f"请输入 MQTT broker 地址 (回车默认 {config.MQTT_SERVER}): ").strip()
        except EOFError:
            s = ""
        host = s or config.MQTT_SERVER

    client = _make_client(f"button-reader-{random.randint(1000, 9999)}")
    if config.MQTT_USERNAME:
        client.username_pw_set(config.MQTT_USERNAME, config.MQTT_PASSWORD)

    def on_connect(c, userdata, flags, rc, properties=None):
        if rc == 0:
            c.subscribe(config.MQTT_TOPIC_BUTTON)
            log("✓", f"connected {host}:{args.port}, subscribed {config.MQTT_TOPIC_BUTTON}")
        else:
            log("✗", f"connect rc={rc}")

    def on_message(c, userdata, msg):
        try:
            text = msg.payload.decode("utf-8")
        except Exception:
            text = repr(msg.payload)
        body = text[len(config.KW_ACTION_LOG):] if text.startswith(config.KW_ACTION_LOG) else text
        try:
            obj = json.loads(body)
            log("◉", f"{obj.get('ts', '?')} [{obj.get('event', '?')}/{obj.get('page', '?')}] "
                     f"{json.dumps(obj.get('payload'), ensure_ascii=False)}")
        except (ValueError, TypeError):
            log("◉", text)

    def on_disconnect(c, userdata, *a, **k):
        log("!", "disconnected (will auto-reconnect)")

    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect

    log("→", f"connecting {host}:{args.port} user={config.MQTT_USERNAME} topic={config.MQTT_TOPIC_BUTTON}")
    try:
        client.connect(host, args.port, keepalive=60)
    except Exception as e:
        log("✗", f"connect failed: {e}")
        return

    try:
        client.loop_forever()
    except KeyboardInterrupt:
        print()
        log("!", "Ctrl+C 退出")
    finally:
        client.disconnect()


if __name__ == "__main__":
    main()
