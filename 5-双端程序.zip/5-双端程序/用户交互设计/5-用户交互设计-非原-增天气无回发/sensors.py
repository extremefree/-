"""传感器层：纯 MQTT 上行 + 用户输入(pH/EC) + 天气(ETo)。

湿度/水箱/本次浇水/结果数完全来自 MQTT，无仿真回退。未收到上报时为 None
(前端显示 '--')，收到后永久保持上一值。今日浇水量由 app.py 服务端累加
(不在此接收)，pH/EC 由用户输入，ETo 由 Open-Meteo 取数。
"""
import config


class SensorHub:
    def __init__(self):
        # MQTT 上行字段：None 表示尚未收到上报
        self.moisture = None
        self.tank = None
        self.last_water = None
        self.today_water = None
        self.fruit = None
        # 用户输入字段
        self.ph = config.DEFAULT_PH
        self.ec = config.DEFAULT_EC
        # 天气字段 (Open-Meteo)
        self.eto_mm = config.DEFAULT_ETO_MM
        self.location = config.DEFAULT_LOCATION

    # ---------- MQTT 上行入口 ----------
    def on_sensor(self, name, value):
        try:
            if name == "moisture":
                self.moisture = max(0, min(100, int(round(float(value)))))
            elif name == "tank":
                self.tank = max(0, min(100, int(round(float(value)))))
            elif name == "last_water":
                self.last_water = int(float(value))
            elif name == "fruit":
                self.fruit = int(float(value))
        except (ValueError, TypeError):
            pass

    # ---------- 用户手动输入 (pH/EC) ----------
    def set_ph(self, v):
        try:
            self.ph = max(0.0, min(14.0, float(v)))
        except (ValueError, TypeError):
            pass

    def set_ec(self, v):
        try:
            self.ec = max(0.0, float(v))
        except (ValueError, TypeError):
            pass

    def set_eto(self, mm, location=None):
        try:
            self.eto_mm = float(mm) if mm is not None else config.DEFAULT_ETO_MM
        except (ValueError, TypeError):
            self.eto_mm = config.DEFAULT_ETO_MM
        if location:
            self.location = location

    # ---------- 周期任务 (无仿真，保留接口供 controller 调用) ----------
    def tick(self):
        pass

    def snapshot(self):
        return {
            "moisture": self.moisture,
            "ph": round(self.ph, 2),
            "ec": round(self.ec, 2),
            "tank": self.tank,
            "fruit": self.fruit,
            "last_water": self.last_water,
            "today_water": self.today_water,
            "eto_mm": round(self.eto_mm, 2),
            "location": self.location,
        }
