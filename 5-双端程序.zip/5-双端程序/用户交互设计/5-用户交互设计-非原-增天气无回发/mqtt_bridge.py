"""MQTT 桥：连接 SIoT、订阅 DFRobot/Seifer、解析上行、封装下行。

修复 server.py 中的两处链式比较 Bug 与 on_message 不消费消息的问题。
"""
import threading

import paho.mqtt.client as mqtt

import config


def _parse_value(payload, keyword):
    """payload 形如 "湿度：35" -> "35"。安全取值，替代脆弱的 [3:-1]。"""
    idx = payload.find(keyword)
    if idx < 0:
        return None
    rest = payload[idx + len(keyword):].strip()
    # 截到下一个非数字字符前
    out = ""
    for ch in rest:
        if ch.isdigit() or ch in ".-":
            out += ch
        else:
            break
    return out or None


def _parse_disease_idx(payload, keyword):
    """解析 '病害：3' / '病害零：3' -> 整数索引(1-6) 或 None。"""
    rest = payload.split(keyword, 1)
    if len(rest) < 2:
        return None
    tail = rest[1].strip()
    num = ""
    for ch in tail:
        if ch.isdigit():
            num += ch
        else:
            break
    if not num:
        return None
    idx = int(num)
    return idx if 1 <= idx <= len(config.DISEASE_NAMES) else None


class MqttBridge:
    def __init__(self):
        self.client = mqtt.Client()
        self.client.username_pw_set(config.MQTT_USERNAME, config.MQTT_PASSWORD)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.connected = False
        # 业务回调 (由外部注入)
        self.on_sensor = None        # fn(name:str, value:str)
        self.on_disease = None       # fn(idx:int, clear:bool)
        self.on_status = None        # fn(connected:bool)
        self._lock = threading.Lock()

    def start(self):
        try:
            self.client.connect(config.MQTT_SERVER, config.MQTT_PORT, 60)
            self.client.loop_start()
            print(f"[mqtt] connecting to {config.MQTT_SERVER}:{config.MQTT_PORT} topic={config.MQTT_TOPIC}",
                  flush=True)
        except OSError as e:
            print(f"[mqtt] connect failed ({e}), uplink disabled (simulator will kick in)", flush=True)

    def stop(self):
        try:
            self.client.loop_stop()
        except Exception:
            pass

    def publish(self, message):
        """下行指令到设备。"""
        try:
            self.client.publish(config.MQTT_TOPIC, message)
            print(f"[mqtt->] {message}", flush=True)
        except Exception as e:
            print(f"[mqtt] publish failed: {e}", flush=True)

    def publish_to(self, topic, message):
        """发布到指定 topic (如操作日志专用通道 BUTTON，与业务总线隔离避免回环)。"""
        try:
            self.client.publish(topic, message)
            print(f"[mqtt->] {topic} -> {message}", flush=True)
        except Exception as e:
            print(f"[mqtt] publish failed: {e}", flush=True)

    # ---------- 回调 ----------
    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self.connected = True
            print("[mqtt] connected", flush=True)
            client.subscribe(config.MQTT_TOPIC)
            self._emit_status(True)
        else:
            print(f"[mqtt] connect rc={rc}", flush=True)

    def _emit_status(self, connected):
        if self.on_status:
            try:
                self.on_status(connected)
            except Exception as e:
                print(f"[mqtt] on_status error: {e}", flush=True)

    def _on_message(self, client, userdata, msg):
        try:
            text = msg.payload.decode("utf-8")
        except Exception:
            return
        print(f"[mqtt<-] {msg.topic} -> {text}", flush=True)
        self._dispatch(text)

    def _dispatch(self, text):
        """按关键字分发上行消息 (替代旧 get()，并修复链式比较 Bug)。

        容忍半角冒号: '病害:1' 与 '病害：1' 等价 (只规范化已知关键字前缀，不动数值)。
        """
        try:
            text = self._normalize_colon(text)
            if text.startswith(config.KW_DISEASE_CLEAR):
                idx = _parse_disease_idx(text, config.KW_DISEASE_CLEAR)
                if idx and self.on_disease:
                    self.on_disease(idx, clear=True)
                return
            if text.startswith(config.KW_DISEASE):
                idx = _parse_disease_idx(text, config.KW_DISEASE)
                if idx and self.on_disease:
                    self.on_disease(idx, clear=False)
                return
            for name, kw in (
                ("moisture", config.KW_MOISTURE),
                ("tank", config.KW_TANK),
                ("last_water", config.KW_LAST_WATER),
                ("fruit", config.KW_FRUIT),
            ):
                if text.startswith(kw):
                    val = _parse_value(text, kw)
                    if val is not None and self.on_sensor:
                        self.on_sensor(name, val)
                    return
        except Exception as e:
            print(f"[mqtt] dispatch error: {e}", flush=True)

    @staticmethod
    def _normalize_colon(text):
        """把已知关键字前缀里的半角 ':' 规范化为全角 '：'。"""
        keywords = (
            config.KW_MOISTURE, config.KW_TANK, config.KW_LAST_WATER,
            config.KW_FRUIT,
            config.KW_DISEASE, config.KW_DISEASE_CLEAR,
        )
        for kw in keywords:
            hw = kw.replace("：", ":")
            if text.startswith(hw) and not text.startswith(kw):
                return kw + text[len(hw):]
        return text
