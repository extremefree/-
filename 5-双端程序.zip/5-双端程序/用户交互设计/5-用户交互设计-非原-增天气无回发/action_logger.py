"""操作日志模块：用户每按一次按钮(后端收到 Socket.IO 事件)即把操作日志发到 MQTT。

发到专用 topic BUTTON (与业务总线 DFRobot/Seifer 隔离，避免回环混淆)，报文形如：
    操作日志：{"ts":"2026-08-13 12:00:00","event":"pump_cmd","payload":{"state":"on"},"page":"fert"}
"""
import json
import time

import config


class ActionLogger:
    def __init__(self, bridge):
        self.bridge = bridge

    def log(self, event, payload=None, page=None):
        record = {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "event": event,
            "payload": payload,
            "page": page,
        }
        self.bridge.publish_to(config.MQTT_TOPIC_BUTTON,
                               config.KW_ACTION_LOG + json.dumps(record, ensure_ascii=False))
