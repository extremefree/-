"""MQTT 测试客户端 — 验证 app.py 的 MQTT 传输链路。

连接到 SIoT broker (与 app.py 同一个)，向 DFRobot/Seifer 发布各关键字上行消息，
并订阅同一主题监听 app.py 的下行指令 (水泵/施肥泵开关)。两边消息都会实时打印，
便于核对 app.py 是否正确解析上行、是否在自动模式下回出下行指令。

用法:
    python mqtt-server.py                      # 交互菜单
    python mqtt-server.py --auto               # 自动演示 (低湿度触发灌溉)
    python mqtt-server.py --host 192.168.3.56  # 指定 broker
    python mqtt-server.py --once "病害：3"      # 发一条指定消息后退出

Ctrl+C 退出。
"""
import argparse
import random
import threading
import time
import sys

import paho.mqtt.client as mqtt

# ---------- 默认配置 (与 app.py / config.py 保持一致) ----------
DEFAULT_HOST = "192.168.3.56"
DEFAULT_PORT = 1883
DEFAULT_USER = "siot"
DEFAULT_PASS = "dfrobot"
DEFAULT_TOPIC = "DFRobot/Seifer"

DISEASE_NAMES = ["白粉病", "斑褐病", "干腐病", "轮斑病", "炭疽病", "锈病"]

# 设备模拟: 水泵开启时按此流速累计水量 (mL/s)
FLOW_RATE_ML_PER_SEC = 12


def _make_client(client_id):
    """创建 paho client，兼容 1.x 与 2.x (避免 2.x 的 CallbackAPIVersion 弃用告警)。"""
    try:
        return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
    except (AttributeError, TypeError):
        return mqtt.Client(client_id=client_id)


def log(tag, msg):
    print(f"[{time.strftime('%H:%M:%S')}] {tag} {msg}", flush=True)


class MqttTester:
    def __init__(self, host, port, user, pwd, topic):
        self.topic = topic
        self.sent_count = 0
        self.recv_count = 0
        self.client = _make_client(f"apple-test-{random.randint(1000,9999)}")
        if user:
            self.client.username_pw_set(user, pwd)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.on_disconnect = self._on_disconnect
        self._host = host
        self._port = port
        self._user = user
        self._connected = threading.Event()
        # 回显抑制: 记录近 2s 内自己 publish 的 payload，收到相同消息视为 broker 回显，跳过
        self._sent_recent = []        # [(ts, payload)]
        # 设备模拟状态: 跟踪水泵启停 -> 上报 本次浇水量 + 连续传感器流
        self.pump_start_ts = None
        self.moisture = 25.0       # 设备侧"测量"的土壤湿度
        self.tank = 80.0           # 水箱水位
        self.fruit = 0             # 结果数量

    # ---- 连接 ----
    def connect(self, timeout=10):
        log("→", f"connecting {self._host}:{self._port} user={self._user} topic={self.topic}")
        try:
            self.client.connect(self._host, self._port, keepalive=60)
        except Exception as e:
            log("✗", f"connect failed: {e}")
            log(" ", "请确认 broker 地址/网络。app.py 与本程序默认连 192.168.3.56:1883。")
            return False
        self.client.loop_start()
        return self._connected.wait(timeout=timeout)

    def _on_connect(self, client, userdata, flags, rc, properties=None):
        if rc == 0:
            self._connected.set()
            log("✓", "connected; subscribed")
            client.subscribe(self.topic)
        else:
            log("✗", f"connect rc={rc}")

    def _on_disconnect(self, client, userdata, *args, **kwargs):
        self._connected.clear()
        log("!", "disconnected (will auto-reconnect)")

    @staticmethod
    def _norm(text):
        """半角冒号规范化为全角，便于匹配下行指令。"""
        return text.replace(":", "：")

    def _on_message(self, client, userdata, msg):
        try:
            text = msg.payload.decode("utf-8")
        except Exception:
            text = repr(msg.payload)
        # 回显抑制: 若是近 2s 内自己发出的消息(broker 回发给自己)，跳过
        now = time.time()
        self._sent_recent = [(ts, p) for (ts, p) in self._sent_recent if now - ts < 2.0]
        if any(p == text for _, p in list(self._sent_recent)):
            return
        # 静默处理 app.py 下行指令 (不打印，避免刷屏干扰菜单控制；详情见 app.py 日志)
        self.recv_count += 1
        n = self._norm(text)
        if n == "水泵：开":
            self.pump_start_ts = time.time()
        elif n == "水泵：关":
            self._close_pump_cycle()

    def _close_pump_cycle(self):
        """水泵关闭: 按运行时长计算本次浇水量后上报，并把水计入湿度上升、水箱下降。"""
        if self.pump_start_ts is None:
            return
        duration = max(0, time.time() - self.pump_start_ts)
        volume = int(duration * FLOW_RATE_ML_PER_SEC)
        self.pump_start_ts = None
        # 物理反馈: 灌溉使湿度上升 (体积/100 近似 %VWC 回升)，水箱下降
        self.moisture = min(100.0, self.moisture + volume / 100.0)
        self.tank = max(0.0, self.tank - volume / 100.0)
        # 今日浇水量改由 app.py 服务端累计，设备只上报本次浇水量
        self.send(f"本次浇水量：{volume}")

    # ---- 发布 ----
    def send(self, payload):
        info = self.client.publish(self.topic, payload)
        self.sent_count += 1
        self._sent_recent.append((time.time(), payload))   # 供 _on_message 回显抑制
        # 不打印每条 MQTT 发布，避免 mqtt-server 生成下游指令日志刷屏。
        # 如需调试，可恢复此行。
        if info.rc != 0:
            log("✗", f'publish failed "{payload}" (rc={info.rc})')

    def close(self):
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception:
            pass


# ---------- 各关键字发送辅助 ----------
def send_moisture(t, v):       t.send(f"湿度：{v}")
def send_tank(t, v):           t.send(f"水箱水位：{v}")
def send_last_water(t, v):     t.send(f"本次浇水量：{v}")
def send_fruit(t, v):          t.send(f"结果数量：{v}")
def send_disease(t, idx):      t.send(f"病害：{idx}")           # 1-6
def send_disease_clear(t, idx): t.send(f"病害零：{idx}")         # 1-6


# ---------- 交互菜单 ----------
MENU = [
    ("1", "湿度：<值>",         "moisture"),
    ("2", "水箱水位：<值>",     "tank"),
    ("3", "本次浇水量：<值>",   "last_water"),
    ("4", "结果数量：<值>",     "fruit"),
    ("5", "病害：<1-6>",        "disease"),
    ("6", "病害零：<1-6>",      "disease_clear"),
    ("a", "自动演示 60s (低湿度触发灌溉)", "auto"),
    ("s", "状态统计",           "stat"),
    ("q", "退出",               "quit"),
]

SENDERS = {
    "moisture":     ("湿度值 (0-100)", send_moisture,      lambda s: int(s)),
    "tank":         ("水箱水位 (0-100)", send_tank,        lambda s: int(s)),
    "last_water":   ("本次浇水量 mL", send_last_water,     lambda s: int(s)),
    "fruit":        ("结果数量", send_fruit,               lambda s: int(s)),
    "disease":      (f"病害编号 1-6 ({'/'.join(DISEASE_NAMES)})", send_disease, lambda s: int(s)),
    "disease_clear":(f"清零病害编号 1-6", send_disease_clear, lambda s: int(s)),
}


def auto_demo(t, duration=60):
    """循环发送低湿度(35)触发 app.py 自动灌溉，并穿插病害/水位。"""
    log("★", f"自动演示 {duration}s — 每 4s 发一次湿度(35)，观察 app.py 下行 水泵：开")
    end = time.time() + duration
    step = 0
    while time.time() < end:
        step += 1
        send_moisture(t, 35)          # 持续低湿度 → 触发 MOISTURE_LOW=40
        if step % 5 == 0:
            send_tank(t, random.randint(60, 90))
        if step % 8 == 0:
            send_disease(t, random.randint(1, 6))
        time.sleep(4)
    log("★", "自动演示结束")


def moisture_stream(t):
    """持续湿度流: 25 → 15 缓慢下降 (跨过触发点 21)，演示完整 MQTT湿度→决策→灌溉 链路。"""
    log("★", "持续湿度流: 每 5s 发一次，25→15 循环下降 (Ctrl+C 退出)")
    seq = [25, 23, 21, 19, 17, 15, 17, 19, 21, 23]  # 跨触发点往返
    i = 0
    while True:
        m = seq[i % len(seq)]
        send_moisture(t, m)
        i += 1
        time.sleep(5)


def device_loop(t):
    """完整设备模拟器: 连续上报全部传感器数据 + 水泵运行时水箱下降。

    app.py 全部传感器数据均来自此流: 湿度/水箱/本次浇水/结果数/病害。
    水泵开关由 app.py 下行触发，本循环据此消耗水箱并在关泵时回传水量。
    今日浇水量由 app.py 累计并跨午夜清零，设备不再上报。
    """
    import random as _r
    log("★", "设备模拟: 每 3s 上报 湿度/水箱/结果数 (moisture 趋干, 水泵开启时水箱下降)")
    # 连接后立即上报全部初值，让 app.py 从 '--' 切到真实值
    send_moisture(t, t.moisture)
    send_tank(t, t.tank)
    send_fruit(t, t.fruit)
    while True:
        # 湿度缓慢趋干 (蒸发)，下限 12
        t.moisture = max(12.0, t.moisture - 0.5)
        send_moisture(t, round(t.moisture, 1))
        # 水泵开启时水箱下降 (~0.5%/s)
        if t.pump_start_ts is not None:
            t.tank = max(0.0, t.tank - 1.5)  # 3s × 0.5%/s
        send_tank(t, round(t.tank, 1))
        # 结果数缓慢递增 (模拟坐果)
        if _r.random() < 0.08:
            t.fruit += 1
            send_fruit(t, t.fruit)
        # 偶发病害
        if _r.random() < 0.03:
            send_disease(t, _r.randint(1, 6))
        time.sleep(3)


def menu_loop(t):
    while True:
        print("\n" + "=" * 52)
        print(" MQTT 测试 — 选择要发送的上行消息")
        print("=" * 52)
        for key, desc, _ in MENU:
            print(f"  [{key}] {desc}")
        choice = input("> ").strip().lower()
        if choice == "q":
            return
        if choice == "a":
            auto_demo(t)
            continue
        if choice == "s":
            log("≡", f"已发送 {t.sent_count} 条 / 已接收 {t.recv_count} 条")
            continue
        action = next((m[2] for m in MENU if m[0] == choice), None)
        if action not in SENDERS:
            print("  无效选项"); continue
        prompt, sender, conv = SENDERS[action]
        raw = input(f"  输入{prompt}: ").strip()
        try:
            val = conv(raw)
            sender(t, val)
        except ValueError:
            print("  ✗ 非法数值")


def main():
    ap = argparse.ArgumentParser(description="MQTT 测试客户端 — 验证 app.py 传输链路")
    ap.add_argument("--host", default=None, help="MQTT broker 地址 (不给则启动时交互输入)")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--user", default=DEFAULT_USER)
    ap.add_argument("--pass", dest="password", default=DEFAULT_PASS)
    ap.add_argument("--topic", default=DEFAULT_TOPIC)
    ap.add_argument("--auto", action="store_true", help="直接进入自动演示 60s")
    ap.add_argument("--moisture-stream", action="store_true",
                    help="持续湿度流: 每 5s 发一个从 25 缓慢降到 15 再循环的湿度，演示完整决策链路")
    ap.add_argument("--device", action="store_true",
                    help="完整设备模拟器: 连续上报全部传感器数据(湿度/水箱/结果数/病害)，水泵运行时水箱下降")
    ap.add_argument("--once", metavar="MSG", help="只发一条指定消息后退出，如 --once '病害：3'")
    args = ap.parse_args()

    # 启动时输入 broker 地址 (未用 --host 指定时)
    host = args.host
    if host is None:
        try:
            s = input(f"请输入 MQTT broker 地址 (回车默认 {DEFAULT_HOST}): ").strip()
        except EOFError:
            s = ""
        host = s or DEFAULT_HOST

    print("=" * 56)
    print(" 苹果园水肥一体化 — MQTT 链路测试客户端 (含设备模拟)")
    print(f" broker: {host}:{args.port}  user={args.user}  topic={args.topic}")
    print(" 提示: 先确保 app.py 已启动并连上同一个 broker")
    print(" 设备模拟: 收到 水泵：开/关 会自动按流速累计并回传 本次浇水量 (今日量由 app.py 累计)")
    print("=" * 56)

    t = MqttTester(host, args.port, args.user, args.password, args.topic)
    if not t.connect():
        sys.exit(1)

    try:
        if args.once:
            t.send(args.once)
            time.sleep(1.5)      # 留时间观察是否有下行
        elif args.device:
            device_loop(t)
        elif args.moisture_stream:
            moisture_stream(t)
        elif args.auto:
            auto_demo(t)
        else:
            menu_loop(t)
    except KeyboardInterrupt:
        print()
        log("!", "Ctrl+C 退出")
    finally:
        log("≡", f"统计: 发送 {t.sent_count} / 接收 {t.recv_count}")
        t.close()


if __name__ == "__main__":
    main()
