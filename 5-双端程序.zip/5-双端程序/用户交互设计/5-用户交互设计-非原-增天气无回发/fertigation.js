/* fertigation.js — 水肥一体化前端逻辑 */
(() => {
  'use strict';

  const socket = io();

  // ===== 时钟 =====
  const clockEl = document.getElementById('clock');
  function tick() {
    const d = new Date(), p = n => String(n).padStart(2, '0');
    if (clockEl) clockEl.textContent = `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }
  tick(); setInterval(tick, 1000);

  // ===== 后端连接状态 =====
  const dot = document.getElementById('backendDot');
  const label = document.getElementById('backendLabel');
  socket.on('connect', () => { dot.classList.add('ok'); label.textContent = '已连接'; });
  socket.on('disconnect', () => { dot.classList.remove('ok'); label.textContent = '已断开'; });

  // ===== 模式 =====
  let curMode = 'auto';
  const modeAuto = document.getElementById('modeAuto');
  const modeManual = document.getElementById('modeManual');
  function applyMode(m) {
    curMode = m;
    modeAuto.classList.toggle('active', m === 'auto');
    modeManual.classList.toggle('active', m === 'manual');
    // 手动开关仅在 manual 模式可点
    document.querySelectorAll('[data-pump],[data-fert]').forEach(b => { b.disabled = (m !== 'manual'); });
  }
  modeAuto.addEventListener('click', () => { applyMode('auto'); socket.emit('mode_cmd', { mode: 'auto' }); });
  modeManual.addEventListener('click', () => { applyMode('manual'); socket.emit('mode_cmd', { mode: 'manual' }); });
  applyMode('auto');

  // ===== 急停 =====
  const estopBar = document.getElementById('estopBar');
  document.getElementById('estopBtn').addEventListener('click', () => socket.emit('estop'));
  document.getElementById('estopResetBtn').addEventListener('click', () => socket.emit('estop_reset'));

  // ===== 执行器开关 =====
  document.querySelectorAll('[data-pump]').forEach(b => {
    b.addEventListener('click', () => socket.emit('pump_cmd', { state: b.dataset.pump }));
  });
  document.querySelectorAll('[data-fert]').forEach(b => {
    b.addEventListener('click', () => socket.emit('fert_cmd', { ch: b.dataset.fert, state: b.dataset.state }));
  });

  // ===== 传感器渲染 =====
  const phInput = document.getElementById('phInput');
  const ecInput = document.getElementById('ecInput');
  // 初始化输入框默认值
  if (phInput) phInput.value = '6.5';
  if (ecInput) ecInput.value = '1.5';
  function sendPhEc() {
    socket.emit('set_ph', { value: parseFloat(phInput.value) });
    socket.emit('set_ec', { value: parseFloat(ecInput.value) });
  }
  if (phInput) phInput.addEventListener('change', sendPhEc);
  if (ecInput) ecInput.addEventListener('change', sendPhEc);

  function setSensor(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }
  const dash = v => (v === null || v === undefined) ? '--' : v;
  socket.on('sensor', s => {
    setSensor('sMoisture', s.moisture == null ? '--' : s.moisture.toFixed(1));
    // pH/EC 是输入框，不覆盖用户正在编辑的值，仅同步非焦点态
    if (phInput && document.activeElement !== phInput) phInput.value = s.ph.toFixed(2);
    if (ecInput && document.activeElement !== ecInput) ecInput.value = s.ec.toFixed(2);
    setSensor('sTank', s.tank == null ? '--' : s.tank.toFixed(1));
    // 阈值着色 (无数据不着色)
    const mBox = document.getElementById('sMoisture')?.closest('.sensor');
    if (mBox) { mBox.classList.remove('warn', 'danger');
      if (s.moisture != null) { if (s.moisture < 21) mBox.classList.add('danger'); else if (s.moisture < 28) mBox.classList.add('warn'); } }
    const tBox = document.getElementById('sTank')?.closest('.sensor');
    if (tBox) { tBox.classList.remove('warn', 'danger'); if (s.tank != null && s.tank < 20) tBox.classList.add('warn'); }
    // ETo 相关
    setSensor('sEto', s.eto_mm != null ? s.eto_mm.toFixed(2) : '--');
    const locEl = document.getElementById('locText'); if (locEl) locEl.textContent = s.location || '--';
    // 湿度图 (无数据跳过该点)
    if (s.moisture != null) pushMoist(s.moisture);
  });

  // ===== MQTT 状态 =====
  socket.on('mqtt_status', d => {
    const dot = document.getElementById('mqttDot');
    const lbl = document.getElementById('mqttLabel');
    if (dot) dot.classList.toggle('ok', !!d.connected);
    if (lbl) lbl.textContent = d.connected ? 'MQTT:已连接' : 'MQTT:未连接';
  });

  // ===== 天气 ETo =====
  document.getElementById('locBtn').addEventListener('click', () => {
    const place = document.getElementById('locInput').value.trim();
    socket.emit('set_location', { place: place || '北京' });
  });
  socket.on('weather', d => {
    setSensor('sEto', d.eto_mm != null ? d.eto_mm.toFixed(2) : '--');
    const locEl = document.getElementById('locText'); if (locEl) locEl.textContent = d.location || '--';
    const tag = document.getElementById('tagEto');
    if (tag) { tag.textContent = d.real ? 'Open-Meteo' : '回退值'; tag.classList.toggle('sim', !d.real); }
  });

  // ===== 灌溉决策 =====
  socket.on('irrigation_decision', d => {
    const dot = document.getElementById('decisionDot');
    const txt = document.getElementById('decisionText');
    if (dot) dot.classList.toggle('ok', !!d.trigger);
    if (txt) txt.textContent = d.trigger ? '需要灌溉' : '暂不需要';
    setSensor('decisionVolume', d.volume_mL || 0);
    setSensor('decisionRefill', d.refill_point);
    setSensor('decisionFc', d.fc);
    setSensor('decisionPwp', d.pwp);
    setSensor('sEtc', d.etc_mm != null ? d.etc_mm.toFixed(2) : '--');
    setSensor('sDailyNeed', d.daily_need_mL || 0);
    const stageTag = document.getElementById('tagStage');
    if (stageTag) stageTag.textContent = d.stage || '--';
    const rEl = document.getElementById('decisionReasons');
    if (rEl) rEl.innerHTML = (d.reasons || []).map(r => `<div>• ${r}</div>`).join('');
    const wEl = document.getElementById('decisionWarnings');
    if (wEl) wEl.innerHTML = (d.warnings || []).map(w => `<div>⚠ ${w}</div>`).join('');
  });

  // ===== 控制器状态 =====
  const recipesAll = ['萌芽期','花期','坐果期','膨大期','着色成熟期','休眠期'];
  const recipeBody = document.getElementById('recipeBody');
  // 先渲染配方表行 (数据从 fert_snapshot 填)
  const PLACEHOLDER = '等待数据…';
  let recipesReceived = false;
  recipesAll.forEach(name => {
    const row = document.createElement('div');
    row.className = 'recipe-row';
    row.dataset.stage = name;
    row.innerHTML = `<span>${name}</span><span class="r-npk">${PLACEHOLDER}</span><span class="r-a">${PLACEHOLDER}</span><span class="r-b">${PLACEHOLDER}</span><span class="r-v">${PLACEHOLDER}</span><span class="r-f">${PLACEHOLDER}</span>`;
    recipeBody.appendChild(row);
  });
  // 生育期下拉
  const stageSelect = document.getElementById('stageSelect');
  recipesAll.forEach(n => { const o = document.createElement('option'); o.value = n; o.textContent = n; stageSelect.appendChild(o); });
  stageSelect.addEventListener('change', () => {
    socket.emit('set_stage', { stage: stageSelect.value || null });
  });

  socket.on('fert_snapshot', st => updateState(st));
  socket.on('fert_state', st => updateState(st));

  function updateState(st) {
    document.getElementById('ledPump').classList.toggle('on', !!st.pump_on);
    document.getElementById('ledFertA').classList.toggle('on', !!st.fert_a_on);
    document.getElementById('ledFertB').classList.toggle('on', !!st.fert_b_on);
    document.getElementById('dailyWater').textContent = (st.daily_water == null) ? '--' : st.daily_water;
    document.getElementById('maxDaily').textContent = st.max_daily_water;
    document.getElementById('canIrr').textContent = st.can_irrigate_reason ? ('⚠ ' + st.can_irrigate_reason) : '';
    estopBar.classList.toggle('show', !!st.paused);
    applyMode(st.mode);
    // 生育期
    stageSelect.value = st.manual_stage || '';
    document.querySelectorAll('.recipe-row').forEach(r => r.classList.remove('current'));
    const curRow = recipeBody.querySelector(`.recipe-row[data-stage="${st.stage}"]`);
    if (curRow) curRow.classList.add('current');
    document.getElementById('adviceText').textContent = st.advice;
    // 配方表数值 (来自 server 端 config)
    if (st.all_recipes) fillRecipes(st.all_recipes);
    // 定时
    if (st.schedule_time) {
      document.getElementById('schedTime').value = st.schedule_time;
      document.getElementById('schedCurrent').style.display = 'inline-flex';
    } else {
      document.getElementById('schedCurrent').style.display = 'none';
    }
  }

  // 首次拿一份完整配方表 (通过单独请求)
  socket.emit('get_recipes', {});
  socket.on('all_recipes', data => fillRecipes(data));
  // 2s 看门狗：若仍未收到配方数据，显示自诊断提示
  setTimeout(() => {
    if (!recipesReceived) {
      const w = document.getElementById('recipeWarn');
      if (w) w.classList.add('show');
      console.warn('[fert] all_recipes 未到达 — 服务器可能是旧版本，请重启 app.py');
    }
  }, 2000);

  function fillRecipes(map) {
    if (!map || !Object.keys(map).length) return;
    recipesReceived = true;
    const warn = document.getElementById('recipeWarn');
    if (warn) warn.classList.remove('show');
    Object.entries(map).forEach(([name, r]) => {
      const row = recipeBody.querySelector(`.recipe-row[data-stage="${name}"]`);
      if (!row) return;
      row.querySelector('.r-npk').textContent = r.npk;
      row.querySelector('.r-a').textContent = r.a_sec;
      row.querySelector('.r-b').textContent = r.b_sec;
      row.querySelector('.r-v').textContent = r.volume;
      row.querySelector('.r-f').textContent = r.freq;
    });
  }

  // ===== 定时 =====
  document.getElementById('schedSave').addEventListener('click', () => {
    const t = document.getElementById('schedTime').value;
    if (!t) return;
    socket.emit('set_schedule', { time: t });
  });
  document.getElementById('schedClear').addEventListener('click', () => {
    document.getElementById('schedTime').value = '';
    socket.emit('set_schedule', { time: null });
  });
  socket.on('schedule_updated', d => {
    document.getElementById('schedCurrent').style.display = d.time ? 'inline-flex' : 'none';
  });

  // ===== 日志 =====
  const logList = document.getElementById('logList');
  function renderLogRow(e) {
    const row = document.createElement('div');
    row.className = 'log-row';
    row.innerHTML = `<span class="src ${e.source}">${e.source}</span><span>${e.time || ''}</span><span>${e.detail || ''}</span>`;
    return row;
  }
  function prependLog(e) {
    if (logList.querySelector('.log-empty')) logList.innerHTML = '';
    logList.insertBefore(renderLogRow(e), logList.firstChild);
    while (logList.children.length > 50) logList.removeChild(logList.lastChild);
  }
  socket.on('irrigation_log', e => prependLog(e));
  socket.on('irrigation_log_full', arr => {
    logList.innerHTML = '';
    if (!arr || !arr.length) { logList.innerHTML = '<div class="log-empty">暂无日志</div>'; return; }
    arr.slice().reverse().forEach(e => logList.appendChild(renderLogRow(e)));
  });
  document.getElementById('refreshLog').addEventListener('click', () => socket.emit('get_log', {}));

  // ===== 湿度趋势图 =====
  const moistData = [];
  const moistLabels = [];
  const moistCtx = document.getElementById('moistChart').getContext('2d');
  const moistChart = new Chart(moistCtx, {
    type: 'line',
    data: { labels: moistLabels, datasets: [{
      label: '土壤湿度(%)', data: moistData, borderColor: '#2e7d32',
      backgroundColor: 'rgba(46,125,50,.15)', tension: 0.3, fill: true, pointRadius: 1.5, borderWidth: 2,
    }]},
    options: {
      responsive: true, maintainAspectRatio: false, animation: false,
      scales: {
        y: { beginAtZero: true, max: 100,
             annotation: {},
             ticks: { color: '#5a7a6a' },
             grid: { color: 'rgba(0,40,20,.08)' } },
        x: { ticks: { color: '#5a7a6a', maxRotation: 0, autoSkipPadding: 12 }, grid: { display: false } },
      },
      plugins: { legend: { labels: { color: '#2a5a3a', boxWidth: 12 } } },
    },
  });
  // 阈值参考线 (用 dataset 实现)
  moistChart.data.datasets.push({ label: '下限40', data: [], borderColor: '#c62828', borderDash: [5,5], pointRadius: 0, borderWidth: 1 });
  moistChart.data.datasets.push({ label: '上限70', data: [], borderColor: '#1565c0', borderDash: [5,5], pointRadius: 0, borderWidth: 1 });

  function pushMoist(v) {
    const d = new Date(), p = n => String(n).padStart(2,'0');
    moistLabels.push(`${p(d.getMinutes())}:${p(d.getSeconds())}`);
    moistData.push(v);
    moistChart.data.datasets[1].data.push(40);
    moistChart.data.datasets[2].data.push(70);
    if (moistLabels.length > 60) {
      moistLabels.shift(); moistData.shift();
      moistChart.data.datasets[1].data.shift();
      moistChart.data.datasets[2].data.shift();
    }
    moistChart.update('none');
  }

  console.log('[fert] initialized');
})();
