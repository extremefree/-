"""天气/ETo 取数：Open-Meteo 地理编码 + FAO-56 日参考蒸散量。

免费、无需 API key。失败一律返回 None，调用方回退默认 ETo。
"""
import json
import urllib.parse
import urllib.request

import config


def _get_json(url, timeout=8):
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        print(f"[weather] {url.split('?')[0]} failed: {e}", flush=True)
        return None


def geocode(place):
    """地名 → (lat, lon, display_name) 或 None。"""
    if not place:
        return None
    qs = urllib.parse.urlencode({"name": place, "count": 1, "language": "zh"})
    data = _get_json(f"{config.OPEN_METEO_GEO_URL}?{qs}")
    if not data or not data.get("results"):
        return None
    r = data["results"][0]
    return (r["latitude"], r["longitude"], r.get("name", place))


def fetch_eto(lat, lon):
    """(lat, lon) → 日 ET0 (mm/d, FAO-56) 或 None。"""
    qs = urllib.parse.urlencode({
        "latitude": lat,
        "longitude": lon,
        "daily": "et0_fao_evapotranspiration",
        "timezone": "auto",
        "forecast_days": 1,
    })
    data = _get_json(f"{config.OPEN_METEO_FORECAST_URL}?{qs}")
    if not data:
        return None
    try:
        vals = data["daily"]["et0_fao_evapotranspiration"]
        if vals and vals[0] is not None:
            return float(vals[0])
    except (KeyError, IndexError, TypeError, ValueError):
        pass
    return None


def eto_for_place(place):
    """地名 → ET0 mm/d (含地理编码)，任意环节失败返回 None。"""
    geo = geocode(place)
    if not geo:
        return None
    lat, lon, _ = geo
    return fetch_eto(lat, lon)
