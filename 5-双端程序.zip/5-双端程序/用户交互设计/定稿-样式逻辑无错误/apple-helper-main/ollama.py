"""ollama 本地模型调用 + 关键词兜底 (从 server.py 平移)。"""
import json
import urllib.request

import config

ADVICE_POOL = [
    "今日土壤湿度适宜，可暂缓浇水。",
    "近期多雨，注意排水防涝，预防灰霉病。",
    "果实膨大期，建议追施钾肥提升糖度。",
    "午后高温，建议开启遮阳网防止日灼。",
    "监测到病害风险，建议喷施保护性杀菌剂。",
]
VALUE_POOL = [
    "当前苹果规格整齐，预计商品果率 85%+，议价能力较强。",
    "糖度检测 14.2°Brix，达优质标准，适合高端渠道。",
    "本周产区均价 6.8 元/kg，建议分批采摘错峰销售。",
    "果径 80mm 以上占比 60%，符合一级果标准。",
]


# 聊天上下文字段: (snapshot key, 标签, 单位)，按展示顺序；None 值省略
CONTEXT_FIELDS = [
    ("moisture", "土壤湿度", "%"),
    ("ph", "pH", ""),
    ("ec", "EC", ""),
    ("tank", "水箱水位", "%"),
    ("fruit", "结果数", ""),
    ("last_water", "本次浇水量", "mL"),
    ("today_water", "今日浇水量", "mL"),
    ("eto_mm", "ET0", "mm/d"),
    ("location", "位置", ""),
    ("stage", "生育期", ""),
]


def _build_system(context):
    """把当前传感器/生育期组成键值清单 system 消息；空则返回 None。"""
    if not context:
        return None
    lines = []
    for key, label, unit in CONTEXT_FIELDS:
        val = context.get(key)
        if val is None:
            continue
        lines.append(f"{label}: {val}{unit}")
    if not lines:
        return None
    return "当前果园实时状态：\n" + "\n".join(lines)


def ollama_chat(q, context=None):
    """调用本地 ollama，附带实时状态 system 消息 (失败回退到 gen_reply)。"""
    messages = []
    sys_msg = _build_system(context or {})
    if sys_msg:
        messages.append({"role": "system", "content": sys_msg})
    messages.append({"role": "user", "content": q})
    payload = json.dumps({
        "model": config.OLLAMA_MODEL,
        "messages": messages,
        "stream": False,
    }).encode("utf-8")
    req = urllib.request.Request(
        config.OLLAMA_URL, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            content = data.get("message", {}).get("content", "").strip()
            return content or "(空回复)"
    except Exception as e:
        print(f"[ollama] failed: {e}", flush=True)
        return f"(ollama 不可用，兜底回复) {gen_reply(q)}"


def gen_reply(q):
    q = q or ""
    if "浇水" in q:
        return "根据土壤湿度监测：当前>60% 可暂缓浇水；低于 40% 建议早晚各浇一次。"
    if "病害" in q or "白粉" in q or "锈病" in q or "灰霉" in q:
        return "常见病害建议：白粉病用醚菌酯，锈病用三唑酮，灰霉病用嘧霉胺，注意通风降湿。"
    if "价值" in q or "价格" in q:
        return "当前苹果达一级果标准，预估产值约 8-12 万元/亩，随行情波动。"
    if "天气" in q:
        return "未来三天以晴为主，午后注意高温日灼，建议开启遮阳网。"
    return "已收到您的问题，建议结合实时监测数据综合判断。"
