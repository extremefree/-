"""水肥精准调控核心：三策略 + 手动覆盖 + 安全约束 + 急停。

策略优先级: 手动覆盖 > 定时灌溉 > 湿度阈值闭环
一次灌溉周期: 查配方 -> 开水泵 + A/B 泵 -> tA/tB 到时分别关 -> 量到关水泵 -> 记账+日志
"""
import json
import threading
import time

import config
import growth_stage
import agronomy


class FertigationController:
    def __init__(self, bridge, sensors, store, socketio):
        self.bridge = bridge
        self.sensors = sensors
        self.store = store
        self.socketio = socketio
        # 运行态
        self.mode = "auto"                      # auto / manual
        self.paused = False                     # 急停
        self.pump_on = False
        self.ferta_on = False
        self.fertb_on = False
        self.last_irrigation_ts = 0.0
        self.current_cycle = None               # dict / None
        self._timers = []                       # 当前周期活动计时器
        self._lock = threading.Lock()
        # 注入 MQTT 病害回调之外的回调
        self.on_irrigation = None               # fn(event_dict)
        # fert 状态镜像到 MQTT 的 diff 缓存
        self._fert_mqtt_last = {}
        self._fert_mqtt_lock = threading.Lock()

    # ---------- 状态快照 ----------
    def state(self):
        with self._lock:
            stage = growth_stage.resolve_stage(manual=self.store.manual_stage)
            rec = growth_stage.get_recipe(stage)
            return {
                "mode": self.mode,
                "paused": self.paused,
                "pump_on": self.pump_on,
                "fert_a_on": self.ferta_on,
                "fert_b_on": self.fertb_on,
                "stage": stage,
                "recipe": rec,
                "advice": growth_stage.advice_text(stage),
                "daily_water": self.sensors.today_water,
                "max_daily_water": config.MAX_DAILY_WATER,
                "schedule_time": self.store.schedule_time,
                "manual_stage": self.store.manual_stage,
                "can_irrigate_reason": self._can_irrigate_reason(),
                "all_recipes": config.GROWTH_RECIPES,
            }

    def _can_irrigate_reason(self):
        if self.paused:
            return "急停中"
        # 今日浇水量由服务端累加 (未上报/启动前按 0 处理)
        tw = self.sensors.today_water or 0
        if tw >= config.MAX_DAILY_WATER:
            return "已达单日浇水上限"
        if time.time() - self.last_irrigation_ts < config.MIN_INTERVAL:
            return "距上次灌溉间隔过短"
        return ""

    # ---------- 每秒巡检 (由 app 后台任务调用) ----------
    def tick(self):
        self.sensors.tick()
        # 计算并广播最新灌溉决策 (无论是否执行，前端都要展示)
        decision = self._compute_decision()
        try:
            self.socketio.emit("irrigation_decision", decision)
        except Exception:
            pass
        # 急停 / 手动模式 / 正在灌溉中 -> 不评估自动策略
        if self.paused or self.mode != "auto":
            return
        if self.current_cycle is not None:
            return
        if decision["trigger"]:
            reason = self._can_irrigate_reason()
            if not reason:
                detail = "; ".join(decision["reasons"] + decision["warnings"])
                self.start_irrigation("湿度阈值", detail=detail, volume_override=decision["volume_mL"])

    def _compute_decision(self):
        stage = growth_stage.resolve_stage(manual=self.store.manual_stage)
        # 湿度尚未从 MQTT 上报 → 无法决策，仅作占位
        if self.sensors.moisture is None:
            return {
                "trigger": False, "volume_mL": 0,
                "refill_point": round(agronomy.refill_point(), 1),
                "fc": config.SOIL_PARAMS["fc"], "pwp": config.SOIL_PARAMS["pwp"],
                "etc_mm": round(agronomy.etc_mm(stage, self.sensors.eto_mm), 2),
                "daily_need_mL": agronomy.daily_need_mL(stage, self.sensors.eto_mm),
                "stage": stage,
                "reasons": ["等待 MQTT 土壤湿度上报…"],
                "warnings": [],
            }
        return agronomy.decide_irrigation(
            self.sensors.moisture, self.sensors.ph, self.sensors.ec,
            stage, self.sensors.eto_mm)

    # ---------- 启动一次灌溉周期 ----------
    def start_irrigation(self, source, detail="", volume_override=None):
        with self._lock:
            if self.current_cycle is not None:
                return False
            reason = self._can_irrigate_reason()
            if reason and source != "manual":
                self._log(source, 0, 0, 0, 0, f"拒绝启动: {reason}")
                return False
            stage = growth_stage.resolve_stage(manual=self.store.manual_stage)
            rec = growth_stage.get_recipe(stage)
            # 灌溉量优先用农学计算值 (volume_override)，否则回退配方默认量；施肥时长仍取配方
            volume = volume_override if volume_override else rec["volume"]
            tA = rec["a_sec"]
            tB = rec["b_sec"]
            self.current_cycle = {
                "source": source, "stage": stage,
                "volume": volume, "a_sec": tA, "b_sec": tB,
                "start_ts": time.time(), "detail": detail,
            }
            self.pump_on = True
            self.ferta_on = tA > 0
            self.fertb_on = tB > 0
            self._publish_actuators()
        # 排程关 A/B 与停止
        if tA > 0:
            self._schedule(tA, lambda: self._turn_off("A"))
        if tB > 0:
            self._schedule(tB, lambda: self._turn_off("B"))
        # 上限取 max(tA, tB) 与 MAX_CYCLE_TIME 中较小作为水泵最长运行时间
        pump_run = max(tA, tB)
        pump_run = min(pump_run if pump_run > 0 else 5, config.MAX_CYCLE_TIME)
        # 至少运行到计量完成
        self._schedule(max(pump_run, 5), self._finish_cycle)
        self._emit_state()
        self._log(source, 0, tA, tB, volume, detail + " 启动")
        return True

    def _turn_off(self, ch):
        with self._lock:
            if ch == "A":
                self.ferta_on = False
            else:
                self.fertb_on = False
            self._publish_actuators()
        self._emit_state()

    def _finish_cycle(self):
        with self._lock:
            if self.current_cycle is None:
                return
            cyc = self.current_cycle
            self.current_cycle = None
            self.pump_on = False
            self.ferta_on = False
            self.fertb_on = False
            self._publish_actuators()
            self.last_irrigation_ts = time.time()
            # 今日/本次浇水量由服务端记账 (本次浇水量经 MQTT 上报，今日浇水量由 app.py 累加)
            self.store.save()
        self._emit_state()
        self._log(cyc["source"], cyc["volume"], cyc["a_sec"], cyc["b_sec"],
                  cyc["volume"], f"{cyc['detail']} 完成".strip())

    # ---------- 手动控制 ----------
    def manual_pump(self, on):
        with self._lock:
            self.mode = "manual"
            self.pump_on = bool(on)
            if not on:
                self.ferta_on = False
                self.fertb_on = False
            self._publish_actuators()
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, f"手动 水泵 {'开' if on else '关'}")

    def manual_fert(self, ch, on):
        with self._lock:
            self.mode = "manual"
            if ch == "A":
                self.ferta_on = bool(on)
            else:
                self.fertb_on = bool(on)
            self._publish_actuators()
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, f"手动 施肥泵{ch} {'开' if on else '关'}")

    def set_mode(self, mode):
        with self._lock:
            self.mode = "manual" if mode == "manual" else "auto"
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, f"模式切换为 {self.mode}")

    def emergency_stop(self):
        self._cancel_timers()
        with self._lock:
            self.paused = True
            self.pump_on = False
            self.ferta_on = False
            self.fertb_on = False
            self.current_cycle = None
            self._publish_actuators()
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, "急停")

    def estop_reset(self):
        with self._lock:
            self.paused = False
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, "解除急停")

    # ---------- 内部工具 ----------
    def _publish_actuators(self):
        self.bridge.publish(config.KW_PUMP_ON if self.pump_on else config.KW_PUMP_OFF)
        self.bridge.publish(config.KW_FERTA_ON if self.ferta_on else config.KW_FERTA_OFF)
        self.bridge.publish(config.KW_FERTB_ON if self.fertb_on else config.KW_FERTB_OFF)

    def _schedule(self, delay, fn):
        t = threading.Timer(delay, fn)
        t.daemon = True
        self._timers.append(t)
        t.start()

    def _cancel_timers(self):
        for t in self._timers:
            try:
                t.cancel()
            except Exception:
                pass
        self._timers = []

    def _emit_state(self):
        # 由 app 注入的 socketio 推送
        try:
            self.socketio.emit("fert_state", self.state())
        except Exception as e:
            print(f"[ctrl] emit failed: {e}", flush=True)
        self.publish_fert_to_mqtt()

    def _log(self, source, volume, a_sec, b_sec, target, detail):
        import datetime as _dt
        entry = {
            "ts": time.time(),
            "time": _dt.datetime.now().strftime("%H:%M:%S"),
            "source": source,
            "volume": volume,
            "target": target,
            "a_sec": a_sec,
            "b_sec": b_sec,
            "detail": detail,
        }
        self.store.add_log(entry)
        self.store.save()
        try:
            self.socketio.emit("irrigation_log", entry)
        except Exception:
            pass
        self.publish_fert_to_mqtt()

    def publish_fert_to_mqtt(self):
        """把 fert 状态以逐字段关键字发到 DFRobot/Seifer，仅发布较上次变化的字段。"""
        try:
            st = self.state()
            sn = self.sensors
            log = self.store.fert_state()["irrigation_log"]
            onoff = lambda b: "开" if b else "关"
            fields = {
                "模式：": st["mode"],
                "急停：": onoff(st["paused"]),
                "水泵状态：": onoff(st["pump_on"]),
                "施肥泵A状态：": onoff(st["fert_a_on"]),
                "施肥泵B状态：": onoff(st["fert_b_on"]),
                "生育期：": st["stage"],
                "手动生育期：": st["manual_stage"] or "无",
                "当前配方：": json.dumps(st["recipe"], ensure_ascii=False),
                "农艺建议：": st["advice"],
                "今日浇水量：": str(st["daily_water"]),
                "日浇水上限：": str(st["max_daily_water"]),
                "定时时刻：": st["schedule_time"] or "无",
                "不可灌溉原因：": st["can_irrigate_reason"] or "无",
                "配方表：": json.dumps(st["all_recipes"], ensure_ascii=False),
                "pH：": str(round(sn.ph, 2)),
                "EC：": str(round(sn.ec, 2)),
                "ET0：": str(round(sn.eto_mm, 2)),
                "位置：": sn.location,
                "灌溉日志：": json.dumps(log, ensure_ascii=False),
            }
        except Exception as e:
            print(f"[ctrl] publish_fert_to_mqtt build failed: {e}", flush=True)
            return
        with self._fert_mqtt_lock:
            for kw, val in fields.items():
                if self._fert_mqtt_last.get(kw) != val:
                    self.bridge.publish(kw + val)
                    self._fert_mqtt_last[kw] = val
