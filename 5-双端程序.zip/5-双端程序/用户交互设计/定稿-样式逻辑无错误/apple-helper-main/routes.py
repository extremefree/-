"""Flask 路由 + 全部 SocketIO handler。

依赖 app.py 注入: store / sensors / controller / bridge / disease_num / last_list。
"""
import functools
import random
import time

import config
import ollama
from action_logger import ActionLogger


def register(app, socketio, store, sensors, controller, bridge, state, refresh_eto=None):
    """state: dict 持有可变共享对象 (disease_num, last_list, last_disease)。"""
    import os
    HERE = os.path.dirname(os.path.abspath(__file__))

    # 操作日志：每个用户触发的 Socket.IO 事件都发一条日志到 MQTT (复用业务 topic)
    action_logger = ActionLogger(bridge)

    def _logged(event, page):
        def deco(fn):
            @functools.wraps(fn)
            def wrapper(data=None):
                action_logger.log(event, data, page)
                return fn(data)
            return wrapper
        return deco

    @app.route("/")
    def index():
        return __import__("flask").send_file(os.path.join(HERE, "camera.html"))

    @app.route("/fert")
    def fert():
        return __import__("flask").send_file(os.path.join(HERE, "fertigation.html"))

    # ============ 监控页事件 (平移自 server.py) ============
    @socketio.on("connect")
    def sio_connect():
        socketio.emit("snapshot", store.snapshot())
        socketio.emit("list", state["last_list"])
        socketio.emit("disease", state["last_disease"])
        socketio.emit("advice", random.choice(ollama.ADVICE_POOL))
        socketio.emit("value", random.choice(ollama.VALUE_POOL))
        # 水肥页快照
        socketio.emit("fert_snapshot", controller.state())
        socketio.emit("sensor", sensors.snapshot())
        socketio.emit("irrigation_log_full", store.fert_state()["irrigation_log"])
        socketio.emit("mqtt_status", {"connected": bridge.connected})
        socketio.emit("weather", {
            "location": sensors.location,
            "eto_mm": round(sensors.eto_mm, 2),
            "real": sensors.eto_mm != config.DEFAULT_ETO_MM or False,
        })

    @socketio.on("disconnect")
    def sio_disconnect():
        print("[socket] client disconnected", flush=True)

    @socketio.on("button")
    @_logged("button", "camera")
    def on_button(data):
        print(f"[button] {data}", flush=True)

    @socketio.on("direction")
    @_logged("direction", "camera")
    def on_direction(data):
        print(f"[direction] {data}", flush=True)

    @socketio.on("pitch")
    @_logged("pitch", "camera")
    def on_pitch(data):
        print(f"[pitch] {data}", flush=True)

    @socketio.on("disease_request")
    @_logged("disease_request", "camera")
    def on_disease_request(data=None):
        _refresh_disease()

    @socketio.on("chat")
    @_logged("chat", "camera")
    def on_chat(msg):
        ctx = dict(sensors.snapshot())
        ctx["stage"] = controller.state().get("stage")
        reply = ollama.ollama_chat(msg, ctx)
        socketio.emit("chat_reply", reply)
        print(f"[chat] Q={msg} A={reply}", flush=True)

    @socketio.on("refresh_advice")
    @_logged("refresh_advice", "camera")
    def on_refresh_advice(data=None):
        socketio.emit("advice", random.choice(ollama.ADVICE_POOL))

    @socketio.on("refresh_value")
    @_logged("refresh_value", "camera")
    def on_refresh_value(data=None):
        socketio.emit("value", random.choice(ollama.VALUE_POOL))

    # ============ 水肥事件 ============
    @socketio.on("pump_cmd")
    @_logged("pump_cmd", "fert")
    def on_pump_cmd(data):
        controller.manual_pump(str(data.get("state")).lower() == "on")

    @socketio.on("fert_cmd")
    @_logged("fert_cmd", "fert")
    def on_fert_cmd(data):
        controller.manual_fert(str(data.get("ch")).upper(), str(data.get("state")).lower() == "on")

    @socketio.on("mode_cmd")
    @_logged("mode_cmd", "fert")
    def on_mode_cmd(data):
        controller.set_mode(data.get("mode", "auto"))

    @socketio.on("estop")
    @_logged("estop", "fert")
    def on_estop(data=None):
        controller.emergency_stop()

    @socketio.on("estop_reset")
    @_logged("estop_reset", "fert")
    def on_estop_reset(data=None):
        controller.estop_reset()

    @socketio.on("set_schedule")
    @_logged("set_schedule", "fert")
    def on_set_schedule(data):
        hhmm = data.get("time")
        store.set_schedule(hhmm)
        store.save()
        socketio.emit("schedule_updated", {"time": hhmm})
        controller.publish_fert_to_mqtt()

    @socketio.on("set_stage")
    @_logged("set_stage", "fert")
    def on_set_stage(data):
        stage = data.get("stage")
        if stage in config.GROWTH_RECIPES or stage in (None, ""):
            store.set_manual_stage(stage or None)
            store.save()
            socketio.emit("fert_state", controller.state())
            controller.publish_fert_to_mqtt()

    @socketio.on("get_recipes")
    def on_get_recipes(data=None):
        socketio.emit("all_recipes", config.GROWTH_RECIPES)

    @socketio.on("get_log")
    @_logged("get_log", "fert")
    def on_get_log(data=None):
        socketio.emit("irrigation_log_full", store.fert_state()["irrigation_log"])

    @socketio.on("set_ph")
    @_logged("set_ph", "fert")
    def on_set_ph(data):
        sensors.set_ph(data.get("value"))
        socketio.emit("sensor", sensors.snapshot())
        controller.publish_fert_to_mqtt()

    @socketio.on("set_ec")
    @_logged("set_ec", "fert")
    def on_set_ec(data):
        sensors.set_ec(data.get("value"))
        socketio.emit("sensor", sensors.snapshot())
        controller.publish_fert_to_mqtt()

    @socketio.on("set_location")
    @_logged("set_location", "fert")
    def on_set_location(data):
        place = (data or {}).get("place") or config.DEFAULT_LOCATION
        if refresh_eto:
            refresh_eto(place)
        else:
            sensors.location = place
            socketio.emit("sensor", sensors.snapshot())

    # ============ 病害刷新 (供监控页) ============
    def _refresh_disease():
        disease = [{"name": n, "count": c}
                   for n, c in zip(config.DISEASE_NAMES, state["disease_num"])]
        state["last_disease"] = disease
        state["last_list"] = list(state["last_list"])
        state["last_list"][5] = sum(d["count"] for d in disease)
        socketio.emit("disease", disease)
        socketio.emit("list", state["last_list"])
