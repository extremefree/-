"""入口：Flask + SocketIO 初始化、后台任务、定时任务、启动。

运行: python app.py
访问: http://localhost:5000/  (监控页)   http://localhost:5000/fert  (水肥页)
"""
import os
import random
import time

import schedule
from flask import Flask
from flask_socketio import SocketIO

import config
import routes
from controller import FertigationController
from mqtt_bridge import MqttBridge
from sensors import SensorHub
from store import DataStore

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(HERE, "data.json")

app = Flask(__name__, static_folder=HERE, static_url_path="")
app.config["SECRET_KEY"] = config.SECRET_KEY
socketio = SocketIO(app, async_mode="threading", cors_allowed_origins="*")

# ---------- 业务对象 ----------
store = DataStore(DATA_FILE)
sensors = SensorHub()
bridge = MqttBridge()
controller = FertigationController(bridge, sensors, store, socketio)

# 共享可变状态 (监控页清单 / 病害)
state = {
    "last_list": [0] * config.NUM_LIST,
    "last_disease": [],
    "disease_num": [0] * len(config.DISEASE_NAMES),
}


# ---------- MQTT 上行回调 ----------
def on_sensor(name, value):
    sensors.on_sensor(name, value)
    # 今日浇水量由服务端累加 (设备只上报本次浇水量)：每次本次浇水量到达即累加并落盘
    if name == "last_water":
        store.add_water(value)
        sensors.today_water = store.daily_water
        store.save()
        controller.publish_fert_to_mqtt()
    # 实时推前端
    socketio.emit("sensor", sensors.snapshot())


def on_disease(idx, clear=False):
    if clear:
        state["disease_num"][idx - 1] = 0
    else:
        state["disease_num"][idx - 1] += 1


bridge.on_sensor = on_sensor
bridge.on_disease = on_disease


def on_mqtt_status(connected):
    print(f"[mqtt] status: {'connected' if connected else 'disconnected'}", flush=True)
    socketio.emit("mqtt_status", {"connected": connected})
    if connected:
        controller.publish_fert_to_mqtt()


bridge.on_status = on_mqtt_status


def refresh_eto(place=None):
    """从 Open-Meteo 拉取日 ET0，更新 sensors 并广播。失败回退默认值。"""
    import weather
    loc = place or sensors.location or config.DEFAULT_LOCATION
    eto = weather.eto_for_place(loc)
    if eto is None:
        print(f"[weather] ETo fetch failed for '{loc}', fallback {config.DEFAULT_ETO_MM} mm/d", flush=True)
        sensors.set_eto(config.DEFAULT_ETO_MM, loc)
    else:
        print(f"[weather] {loc} ETo={eto:.2f} mm/d", flush=True)
        sensors.set_eto(eto, loc)
    socketio.emit("weather", {
        "location": sensors.location,
        "eto_mm": round(sensors.eto_mm, 2),
        "real": eto is not None,
    })
    socketio.emit("sensor", sensors.snapshot())
    controller.publish_fert_to_mqtt()


# ---------- 路由与事件 ----------
routes.register(app, socketio, store, sensors, controller, bridge, state, refresh_eto)


# ---------- 后台任务 ----------
def background_push():
    """每分钟生成一个监控页折线点；每秒推送传感器 + 控制巡检。"""
    socketio.sleep(1.0)
    sec_counter = 0
    while True:
        # 每秒：控制巡检 + 推送 (传感器数据全来自 MQTT，可能为 None)
        controller.tick()
        socketio.emit("sensor", sensors.snapshot())
        # 监控页清单：第 0=湿度, 1=水箱, 3=今日浇水, 4=本次浇水, 5=病害, 2=结果数
        state["last_list"][0] = sensors.moisture
        state["last_list"][1] = sensors.tank
        state["last_list"][2] = sensors.fruit
        state["last_list"][3] = sensors.today_water
        state["last_list"][4] = sensors.last_water
        disease = [{"name": n, "count": c}
                   for n, c in zip(config.DISEASE_NAMES, state["disease_num"])]
        state["last_list"][5] = sum(d["count"] for d in disease)
        state["last_disease"] = disease
        socketio.emit("list", state["last_list"])
        socketio.emit("disease", state["last_disease"])

        # 每分钟：生成新折线点 (只生成一次) — 数据来自 MQTT/主程序真实值
        sec_counter += 1
        m = int(time.time() // 60 * 60)
        if not store.has_minute(m):
            disease_total = sum(state["disease_num"])
            # 图表0=土壤湿度, 1=病害数量, 2=结果数量；None 时该槽为 null(charts.js 跳过)
            pt = [
                {"line": sensors.moisture} if sensors.moisture is not None else None,
                {"line": disease_total},
                {"line": sensors.fruit} if sensors.fruit is not None else None,
            ]
            store.set_minute(m, pt)
            store.save()
            socketio.emit("point", {"t": m, "charts": pt})

        socketio.sleep(config.SAMPLE_INTERVAL)


def schedule_loop():
    while True:
        try:
            schedule.run_pending()
        except Exception as e:
            print(f"[schedule] run error: {e}", flush=True)
        time.sleep(1)


def daily_reset():
    """每日 0 点：清零病害计数 + 今日浇水量 (保留日志)。"""
    for i in range(len(state["disease_num"])):
        state["disease_num"][i] = 0
    store.daily_reset()
    sensors.today_water = 0
    store.save()
    print(f"[daily] reset @ {time.strftime('%F %T')}", flush=True)


def timed_irrigation():
    """定时灌溉触发 (由 schedule 调度)。"""
    if controller.mode == "auto" and not controller.paused:
        controller.start_irrigation("定时灌溉", detail=f"定时 {store.schedule_time}")


def _reschedule_timed():
    if store.schedule_time:
        try:
            schedule.every().day.at(store.schedule_time).do(timed_irrigation)
            print(f"[schedule] timed irrigation at {store.schedule_time}", flush=True)
        except Exception as e:
            print(f"[schedule] register failed: {e}", flush=True)


# schedule 必须在 socketio.run 之前注册 (修复原 Bug)
schedule.every().day.at("00:00").do(daily_reset)
schedule.every().day.at("06:00").do(lambda: refresh_eto())
_reschedule_timed()


def _prompt_broker():
    """启动时交互输入 MQTT broker 地址 (回车用默认)。"""
    default = config.MQTT_SERVER
    try:
        s = input(f"请输入 MQTT broker 地址 (回车默认 {default}): ").strip()
    except EOFError:
        s = ""
    addr = s or default
    config.MQTT_SERVER = addr
    return addr


if __name__ == "__main__":
    # 启动时恢复今日浇水量累计 (湿度/水箱/本次浇水等仍来自 MQTT，保持 None)
    sensors.today_water = store.daily_water
    _prompt_broker()
    bridge.start()
    socketio.start_background_task(background_push)
    socketio.start_background_task(schedule_loop)
    socketio.start_background_task(lambda: (refresh_eto(),))  # 启动即拉一次 ETo
    print(f"[server] http://localhost:{config.PORT}/  (监控页)  /fert  (水肥页)", flush=True)
    socketio.run(app, host=config.HOST, port=config.PORT,
                 allow_unsafe_werkzeug=True, debug=False)
