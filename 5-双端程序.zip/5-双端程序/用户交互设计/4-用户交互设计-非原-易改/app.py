"""入口：Flask + SocketIO 初始化、后台任务、定时任务、启动。

运行: python app.py
访问: http://localhost:5000/  (监控页)   http://localhost:5000/fert  (水肥页)
"""
import os
import random
import time

import schedule
from flask import Flask
from flask_socketio import SocketIO

import config
import routes
from controller import FertigationController
from mqtt_bridge import MqttBridge
from sensors import SensorHub
from store import DataStore

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(HERE, "data.json")

app = Flask(__name__, static_folder=HERE, static_url_path="")
app.config["SECRET_KEY"] = config.SECRET_KEY
socketio = SocketIO(app, async_mode="threading", cors_allowed_origins="*")

# ---------- 业务对象 ----------
store = DataStore(DATA_FILE)
sensors = SensorHub()
bridge = MqttBridge()
controller = FertigationController(bridge, sensors, store, socketio)

# 共享可变状态 (监控页清单 / 病害)
state = {
    "last_list": [0] * config.NUM_LIST,
    "last_disease": [],
    "disease_num": [0] * len(config.DISEASE_NAMES),
}


# ---------- MQTT 上行回调 ----------
def on_sensor(name, value):
    sensors.on_sensor(name, value)
    # 今日浇水量由本次浇水量累加或设备上报 -> 同步到持久化缓存 (供重启恢复 + UI 连续显示)
    if name in ("today_water", "last_water"):
        store.set_daily_water(sensors.today_water)
    # 实时推前端
    socketio.emit("sensor", sensors.snapshot())


def on_disease(idx, clear=False):
    if clear:
        state["disease_num"][idx - 1] = 0
    else:
        state["disease_num"][idx - 1] += 1


bridge.on_sensor = on_sensor
bridge.on_disease = on_disease


# ---------- 路由与事件 ----------
routes.register(app, socketio, store, sensors, controller, bridge, state)


# ---------- 后台任务 ----------
def background_push():
    """每分钟生成一个监控页折线点；每秒推送传感器 + 控制巡检。"""
    socketio.sleep(1.0)
    sec_counter = 0
    while True:
        # 每秒：传感器仿真 + 控制巡检 + 推送
        controller.tick()
        socketio.emit("sensor", sensors.snapshot())
        # 监控页清单：第 0=湿度, 1=水箱, 3=今日浇水, 4=本次浇水, 5=病害, 2=结果数
        state["last_list"][0] = int(sensors.moisture)
        state["last_list"][1] = int(sensors.tank)
        state["last_list"][2] = sensors.fruit
        state["last_list"][3] = sensors.today_water
        state["last_list"][4] = sensors.last_water
        disease = [{"name": n, "count": c}
                   for n, c in zip(config.DISEASE_NAMES, state["disease_num"])]
        state["last_list"][5] = sum(d["count"] for d in disease)
        state["last_disease"] = disease
        socketio.emit("list", state["last_list"])
        socketio.emit("disease", state["last_disease"])

        # 每分钟：生成新折线点 (只生成一次)
        sec_counter += 1
        m = int(time.time() // 60 * 60)
        if not store.has_minute(m):
            # 使用真实传感器值填充三张曲线：土壤湿度 / 每日浇水量 / 结果数量
            pt = [
                {"line": float(sensors.moisture)},
                {"line": float(sensors.today_water)},
                {"line": float(sensors.fruit)},
            ]
            store.set_minute(m, pt)
            store.save()
            socketio.emit("point", {"t": m, "charts": pt})

        socketio.sleep(config.SAMPLE_INTERVAL)


def schedule_loop():
    while True:
        try:
            schedule.run_pending()
        except Exception as e:
            print(f"[schedule] run error: {e}", flush=True)
        time.sleep(1)


def daily_reset():
    """每日 0 点：清零今日浇水量与病害计数 (保留日志)。"""
    sensors.reset_daily()
    store.daily_reset()
    store.save()
    for i in range(len(state["disease_num"])):
        state["disease_num"][i] = 0
    print(f"[daily] reset @ {time.strftime('%F %T')}", flush=True)


def timed_irrigation():
    """定时灌溉触发 (由 schedule 调度)。"""
    if controller.mode == "auto" and not controller.paused:
        controller.start_irrigation("定时灌溉", detail=f"定时 {store.schedule_time}")


def _reschedule_timed():
    if store.schedule_time:
        try:
            schedule.every().day.at(store.schedule_time).do(timed_irrigation)
            print(f"[schedule] timed irrigation at {store.schedule_time}", flush=True)
        except Exception as e:
            print(f"[schedule] register failed: {e}", flush=True)


# schedule 必须在 socketio.run 之前注册 (修复原 Bug)
schedule.every().day.at("00:00").do(daily_reset)
_reschedule_timed()


def _prompt_broker():
    """启动时交互输入 MQTT broker 地址 (回车用默认)。"""
    default = config.MQTT_SERVER
    try:
        s = input(f"请输入 MQTT broker 地址 (回车默认 {default}): ").strip()
    except EOFError:
        s = ""
    addr = s or default
    config.MQTT_SERVER = addr
    return addr


if __name__ == "__main__":
    # 今日浇水量从持久化缓存恢复 (设备首次上报前用上次值，避免显示 0)
    sensors.today_water = store.daily_water
    _prompt_broker()
    bridge.start()
    socketio.start_background_task(background_push)
    socketio.start_background_task(schedule_loop)
    print(f"[server] http://localhost:{config.PORT}/  (监控页)  /fert  (水肥页)", flush=True)
    socketio.run(app, host=config.HOST, port=config.PORT,
                 allow_unsafe_werkzeug=True, debug=False)
