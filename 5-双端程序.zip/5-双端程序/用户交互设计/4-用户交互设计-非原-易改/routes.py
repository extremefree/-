"""Flask 路由 + 全部 SocketIO handler。

依赖 app.py 注入: store / sensors / controller / bridge / disease_num / last_list。
"""
import json
import random
import time

import config
import ollama


def register(app, socketio, store, sensors, controller, bridge, state):
    """state: dict 持有可变共享对象 (disease_num, last_list, last_disease)。"""
    import os
    HERE = os.path.dirname(os.path.abspath(__file__))

    @app.route("/")
    def index():
        return __import__("flask").send_file(os.path.join(HERE, "camera.html"))

    @app.route("/fert")
    def fert():
        return __import__("flask").send_file(os.path.join(HERE, "fertigation.html"))

    # ============ 监控页事件 (平移自 server.py) ============
    @socketio.on("connect")
    def sio_connect():
        socketio.emit("snapshot", store.snapshot())
        socketio.emit("list", state["last_list"])
        socketio.emit("disease", state["last_disease"])
        socketio.emit("advice", random.choice(ollama.ADVICE_POOL))
        socketio.emit("value", random.choice(ollama.VALUE_POOL))
        # 水肥页快照
        socketio.emit("fert_snapshot", controller.state())
        socketio.emit("sensor", sensors.snapshot())
        socketio.emit("irrigation_log_full", store.fert_state()["irrigation_log"])

    @socketio.on("disconnect")
    def sio_disconnect():
        print("[socket] client disconnected", flush=True)

    @socketio.on("button")
    def on_button(data):
        print(f"[button] {data}", flush=True)
        try:
            payload = json.dumps({"type": "button", "payload": data}, ensure_ascii=False)
            bridge.publish(payload)
        except Exception as e:
            print(f"[mqtt] button publish failed: {e}", flush=True)

    @socketio.on("direction")
    def on_direction(data):
        print(f"[direction] {data}", flush=True)

    @socketio.on("pitch")
    def on_pitch(data):
        print(f"[pitch] {data}", flush=True)

    @socketio.on("disease_request")
    def on_disease_request(data=None):
        _refresh_disease()

    @socketio.on("chat")
    def on_chat(msg):
        reply = ollama.ollama_chat(msg)
        socketio.emit("chat_reply", reply)
        print(f"[chat] Q={msg} A={reply}", flush=True)

    @socketio.on("refresh_advice")
    def on_refresh_advice(data=None):
        socketio.emit("advice", random.choice(ollama.ADVICE_POOL))

    @socketio.on("refresh_value")
    def on_refresh_value(data=None):
        socketio.emit("value", random.choice(ollama.VALUE_POOL))

    # ============ 水肥事件 ============
    @socketio.on("pump_cmd")
    def on_pump_cmd(data):
        controller.manual_pump(str(data.get("state")).lower() == "on")

    @socketio.on("fert_cmd")
    def on_fert_cmd(data):
        controller.manual_fert(str(data.get("ch")).upper(), str(data.get("state")).lower() == "on")

    @socketio.on("mode_cmd")
    def on_mode_cmd(data):
        controller.set_mode(data.get("mode", "auto"))

    @socketio.on("estop")
    def on_estop(data=None):
        controller.emergency_stop()

    @socketio.on("estop_reset")
    def on_estop_reset(data=None):
        controller.estop_reset()

    @socketio.on("set_schedule")
    def on_set_schedule(data):
        hhmm = data.get("time")
        store.set_schedule(hhmm)
        store.save()
        socketio.emit("schedule_updated", {"time": hhmm})

    @socketio.on("set_stage")
    def on_set_stage(data):
        stage = data.get("stage")
        if stage in config.GROWTH_RECIPES or stage in (None, ""):
            store.set_manual_stage(stage or None)
            store.save()
            socketio.emit("fert_state", controller.state())

    @socketio.on("get_recipes")
    def on_get_recipes(data=None):
        socketio.emit("all_recipes", config.GROWTH_RECIPES)

    @socketio.on("get_log")
    def on_get_log(data=None):
        socketio.emit("irrigation_log_full", store.fert_state()["irrigation_log"])

    # ============ 病害刷新 (供监控页) ============
    def _refresh_disease():
        disease = [{"name": n, "count": c}
                   for n, c in zip(config.DISEASE_NAMES, state["disease_num"])]
        state["last_disease"] = disease
        state["last_list"] = list(state["last_list"])
        state["last_list"][5] = sum(d["count"] for d in disease)
        socketio.emit("disease", disease)
        socketio.emit("list", state["last_list"])
