"""数据持久化：监控页折线历史 + 水肥运行状态 + 灌溉日志。

JSON 顶层结构:
{
  "<minute_ts>": [{"line": float}, ...],     # 监控页历史 (保留旧格式, 兼容)
  "fertigation": {
      "daily_water": int,                    # 当日累计浇水 mL
      "irrigation_log": [ {ts, source, volume, a_sec, b_sec, stage}, ... ],
      "schedule_time": "HH:MM" | null,       # 定时灌溉时刻
      "manual_stage": "膨大期" | null         # 手动覆盖生育期
  }
}
"""
import json
import os
import threading

import config


class DataStore:
    def __init__(self, path):
        self.path = path
        self.data_store = {}                 # minute_ts -> [{line}, ...]
        self.daily_water = 0
        self.irrigation_log = []
        self.schedule_time = None
        self.manual_stage = None
        self._lock = threading.Lock()
        self.load()

    # ---------- 监控页折线 ----------
    def has_minute(self, m):
        return m in self.data_store

    def set_minute(self, m, pt):
        with self._lock:
            self.data_store[m] = pt

    def snapshot(self):
        with self._lock:
            return [{"t": k, "charts": v} for k, v in sorted(self.data_store.items())]

    # ---------- 水肥记账 ----------
    def add_water(self, ml):
        with self._lock:
            self.daily_water += ml

    def set_daily_water(self, ml):
        """由 MQTT 上报的今日浇水量覆盖本地记账 (设备是水源真值)。"""
        with self._lock:
            self.daily_water = max(0, int(ml))

    def add_log(self, entry):
        with self._lock:
            self.irrigation_log.append(entry)
            if len(self.irrigation_log) > config.IRRIGATION_LOG_MAX:
                self.irrigation_log = self.irrigation_log[-config.IRRIGATION_LOG_MAX:]

    def set_schedule(self, hhmm):
        with self._lock:
            self.schedule_time = hhmm

    def set_manual_stage(self, stage):
        with self._lock:
            self.manual_stage = stage

    def daily_reset(self):
        with self._lock:
            self.daily_water = 0

    def fert_state(self):
        with self._lock:
            return {
                "daily_water": self.daily_water,
                "irrigation_log": list(self.irrigation_log[-50:]),
                "schedule_time": self.schedule_time,
                "manual_stage": self.manual_stage,
            }

    # ---------- 落盘 / 读盘 ----------
    def load(self):
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as e:
            print(f"[store] load failed: {e}", flush=True)
            return
        for k, v in raw.items():
            if k == "fertigation":
                continue
            try:
                self.data_store[int(k)] = v
            except (ValueError, TypeError):
                pass
        fert = raw.get("fertigation")
        if isinstance(fert, dict):
            self.daily_water = int(fert.get("daily_water", 0))
            log = fert.get("irrigation_log", [])
            self.irrigation_log = list(log) if isinstance(log, list) else []
            self.schedule_time = fert.get("schedule_time")
            self.manual_stage = fert.get("manual_stage")
        print(f"[store] loaded {len(self.data_store)} minutes, daily_water={self.daily_water}, "
              f"log={len(self.irrigation_log)}", flush=True)

    def save(self):
        """原子写：tmp + os.replace。"""
        with self._lock:
            payload = {str(k): v for k, v in self.data_store.items()}
            payload["fertigation"] = {
                "daily_water": self.daily_water,
                "irrigation_log": list(self.irrigation_log),
                "schedule_time": self.schedule_time,
                "manual_stage": self.manual_stage,
            }
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except Exception as e:
            print(f"[store] save failed: {e}", flush=True)
