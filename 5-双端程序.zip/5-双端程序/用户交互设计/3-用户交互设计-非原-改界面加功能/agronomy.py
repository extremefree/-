"""农学决策引擎：土壤湿度触发 + ETc 蒸散法 + pH/EC 调节。

依据 FAO 灌排手册 56 (Penman-Monteith)、苹果园灌溉研究与标准土壤水分物理。
"""
import config


def refill_point(sp=None):
    """灌溉触发点 = FC − MAD × (FC − PWP)。"""
    sp = sp or config.SOIL_PARAMS
    return sp["fc"] - sp["mad"] * (sp["fc"] - sp["pwp"])


def compute_volume(moisture, sp=None):
    """补满到 FC 所需水量 (mL) = (FC−moisture)/100 × root_depth × wetted_area × 1000。"""
    sp = sp or config.SOIL_PARAMS
    deficit = max(0.0, (sp["fc"] - moisture) / 100.0)
    refill_depth_mm = deficit * sp["root_depth_mm"]
    return int(round(refill_depth_mm * sp["wetted_area_m2"] * 1000))


def kc_for_stage(stage):
    return config.APPLE_KC.get(stage, config.APPLE_KC["休眠期"])


def etc_mm(stage, eto_mm):
    """作物蒸散量 ETc = Kc × ETo (mm/d)。"""
    return kc_for_stage(stage) * (eto_mm if eto_mm is not None else config.DEFAULT_ETO_MM)


def daily_need_mL(stage, eto_mm, sp=None):
    """单树每日需水量估算 (mL) = ETc × wetted_area × 1000。"""
    sp = sp or config.SOIL_PARAMS
    return int(round(etc_mm(stage, eto_mm) * sp["wetted_area_m2"] * 1000))


def decide_irrigation(moisture, ph, ec, stage, eto_mm, sp=None):
    """综合决策：是否灌溉、灌多少、原因与告警。

    返回 dict: {trigger, volume_mL, refill_point, etc_mm, daily_need_mL,
                reasons[], warnings[]}
    """
    sp = sp or config.SOIL_PARAMS
    rp = refill_point(sp)
    etc = etc_mm(stage, eto_mm)
    daily = daily_need_mL(stage, eto_mm, sp)
    reasons = []
    warnings = []

    need = moisture <= rp
    if need:
        reasons.append(f"土壤湿度 {moisture:.0f}% ≤ 触发点 {rp:.0f}% (FC{sp['fc']:.0f}/PWP{sp['pwp']:.0f}/MAD{int(sp['mad']*100)}%)")
    else:
        reasons.append(f"土壤湿度 {moisture:.0f}% > 触发点 {rp:.0f}%，暂不需灌溉")

    volume = compute_volume(moisture, sp) if need else 0

    # pH 越界告警
    if ph is not None and (ph < config.PH_MIN or ph > config.PH_MAX):
        side = "偏酸" if ph < config.PH_MIN else "偏碱"
        warnings.append(f"pH={ph:.2f} {side} (适宜 {config.PH_MIN}-{config.PH_MAX})，可能影响养分吸收")

    # EC 调节灌溉量
    if ec is not None and need:
        if ec > config.EC_SALINITY:
            volume = int(round(volume * (1 + config.LEACHING_FRACTION)))
            warnings.append(f"EC={ec:.2f} > {config.EC_SALINITY}，已加 {int(config.LEACHING_FRACTION*100)}% 淋洗水量排盐")
        elif ec < config.EC_LOW:
            warnings.append(f"EC={ec:.2f} < {config.EC_LOW}，养分偏低，建议补肥")

    return {
        "trigger": need,
        "volume_mL": volume,
        "refill_point": round(rp, 1),
        "fc": sp["fc"],
        "pwp": sp["pwp"],
        "etc_mm": round(etc, 2),
        "daily_need_mL": daily,
        "reasons": reasons,
        "warnings": warnings,
    }
