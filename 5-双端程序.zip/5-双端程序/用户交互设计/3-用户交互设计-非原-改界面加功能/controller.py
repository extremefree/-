"""水肥精准调控核心：三策略 + 手动覆盖 + 安全约束 + 急停。

策略优先级: 手动覆盖 > 定时灌溉 > 湿度阈值闭环
一次灌溉周期: 查配方 -> 开水泵 + A/B 泵 -> tA/tB 到时分别关 -> 量到关水泵 -> 记账+日志
"""
import threading
import time

import config
import growth_stage


class FertigationController:
    def __init__(self, bridge, sensors, store, socketio):
        self.bridge = bridge
        self.sensors = sensors
        self.store = store
        self.socketio = socketio
        # 运行态
        self.mode = "auto"                      # auto / manual
        self.paused = False                     # 急停
        self.pump_on = False
        self.ferta_on = False
        self.fertb_on = False
        self.last_irrigation_ts = 0.0
        self.current_cycle = None               # dict / None
        self._timers = []                       # 当前周期活动计时器
        self._lock = threading.Lock()
        # 注入 MQTT 病害回调之外的回调
        self.on_irrigation = None               # fn(event_dict)

    # ---------- 状态快照 ----------
    def state(self):
        with self._lock:
            stage = growth_stage.resolve_stage(manual=self.store.manual_stage)
            rec = growth_stage.get_recipe(stage)
            return {
                "mode": self.mode,
                "paused": self.paused,
                "pump_on": self.pump_on,
                "fert_a_on": self.ferta_on,
                "fert_b_on": self.fertb_on,
                "stage": stage,
                "recipe": rec,
                "advice": growth_stage.advice_text(stage),
                "daily_water": self.sensors.today_water,
                "daily_water_real": self.sensors.today_water_real,
                "max_daily_water": config.MAX_DAILY_WATER,
                "schedule_time": self.store.schedule_time,
                "manual_stage": self.store.manual_stage,
                "can_irrigate_reason": self._can_irrigate_reason(),
                "all_recipes": config.GROWTH_RECIPES,
            }

    def _can_irrigate_reason(self):
        if self.paused:
            return "急停中"
        # 今日浇水量以设备 MQTT 上报为准
        if self.sensors.today_water >= config.MAX_DAILY_WATER:
            return "已达单日浇水上限"
        if time.time() - self.last_irrigation_ts < config.MIN_INTERVAL:
            return "距上次灌溉间隔过短"
        return ""

    # ---------- 每秒巡检 (由 app 后台任务调用) ----------
    def tick(self):
        self.sensors.tick()
        # 急停 / 手动模式 / 正在灌溉中 -> 不评估自动策略
        if self.paused or self.mode != "auto":
            return
        if self.current_cycle is not None:
            return
        # 湿度阈值闭环
        m = self.sensors.moisture
        if m < config.MOISTURE_LOW:
            reason = self._can_irrigate_reason()
            if not reason:
                self.start_irrigation("湿度阈值", detail=f"湿度 {int(m)}% < {config.MOISTURE_LOW}")

    # ---------- 启动一次灌溉周期 ----------
    def start_irrigation(self, source, detail=""):
        with self._lock:
            if self.current_cycle is not None:
                return False
            reason = self._can_irrigate_reason()
            if reason and source != "manual":
                self._log(source, 0, 0, 0, 0, f"拒绝启动: {reason}")
                return False
            stage = growth_stage.resolve_stage(manual=self.store.manual_stage)
            rec = growth_stage.get_recipe(stage)
            volume = rec["volume"]
            tA = rec["a_sec"]
            tB = rec["b_sec"]
            self.current_cycle = {
                "source": source, "stage": stage,
                "volume": volume, "a_sec": tA, "b_sec": tB,
                "start_ts": time.time(), "detail": detail,
            }
            self.pump_on = True
            self.ferta_on = tA > 0
            self.fertb_on = tB > 0
            self._publish_actuators()
        # 排程关 A/B 与停止
        if tA > 0:
            self._schedule(tA, lambda: self._turn_off("A"))
        if tB > 0:
            self._schedule(tB, lambda: self._turn_off("B"))
        # 上限取 max(tA, tB) 与 MAX_CYCLE_TIME 中较小作为水泵最长运行时间
        pump_run = max(tA, tB)
        pump_run = min(pump_run if pump_run > 0 else 5, config.MAX_CYCLE_TIME)
        # 至少运行到计量完成
        self._schedule(max(pump_run, 5), self._finish_cycle)
        self._emit_state()
        self._log(source, 0, tA, tB, volume, detail + " 启动")
        return True

    def _turn_off(self, ch):
        with self._lock:
            if ch == "A":
                self.ferta_on = False
            else:
                self.fertb_on = False
            self._publish_actuators()
        self._emit_state()

    def _finish_cycle(self):
        with self._lock:
            if self.current_cycle is None:
                return
            cyc = self.current_cycle
            self.current_cycle = None
            self.pump_on = False
            self.ferta_on = False
            self.fertb_on = False
            self._publish_actuators()
            self.last_irrigation_ts = time.time()
            # 今日/本次浇水量由设备经 MQTT 上报 (今日浇水量：/本次浇水量：)，服务端不再本地累计
            self.store.save()
        self._emit_state()
        self._log(cyc["source"], cyc["volume"], cyc["a_sec"], cyc["b_sec"],
                  cyc["volume"], f"{cyc['detail']} 完成".strip())

    # ---------- 手动控制 ----------
    def manual_pump(self, on):
        with self._lock:
            self.mode = "manual"
            self.pump_on = bool(on)
            if not on:
                self.ferta_on = False
                self.fertb_on = False
            self._publish_actuators()
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, f"手动 水泵 {'开' if on else '关'}")

    def manual_fert(self, ch, on):
        with self._lock:
            self.mode = "manual"
            if ch == "A":
                self.ferta_on = bool(on)
            else:
                self.fertb_on = bool(on)
            self._publish_actuators()
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, f"手动 施肥泵{ch} {'开' if on else '关'}")

    def set_mode(self, mode):
        with self._lock:
            self.mode = "manual" if mode == "manual" else "auto"
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, f"模式切换为 {self.mode}")

    def emergency_stop(self):
        self._cancel_timers()
        with self._lock:
            self.paused = True
            self.pump_on = False
            self.ferta_on = False
            self.fertb_on = False
            self.current_cycle = None
            self._publish_actuators()
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, "急停")

    def estop_reset(self):
        with self._lock:
            self.paused = False
        self._emit_state()
        self._log("manual", 0, 0, 0, 0, "解除急停")

    # ---------- 内部工具 ----------
    def _publish_actuators(self):
        self.bridge.publish(config.KW_PUMP_ON if self.pump_on else config.KW_PUMP_OFF)
        self.bridge.publish(config.KW_FERTA_ON if self.ferta_on else config.KW_FERTA_OFF)
        self.bridge.publish(config.KW_FERTB_ON if self.fertb_on else config.KW_FERTB_OFF)

    def _schedule(self, delay, fn):
        t = threading.Timer(delay, fn)
        t.daemon = True
        self._timers.append(t)
        t.start()

    def _cancel_timers(self):
        for t in self._timers:
            try:
                t.cancel()
            except Exception:
                pass
        self._timers = []

    def _emit_state(self):
        # 由 app 注入的 socketio 推送
        try:
            self.socketio.emit("fert_state", self.state())
        except Exception as e:
            print(f"[ctrl] emit failed: {e}", flush=True)

    def _log(self, source, volume, a_sec, b_sec, target, detail):
        import datetime as _dt
        entry = {
            "ts": time.time(),
            "time": _dt.datetime.now().strftime("%H:%M:%S"),
            "source": source,
            "volume": volume,
            "target": target,
            "a_sec": a_sec,
            "b_sec": b_sec,
            "detail": detail,
        }
        self.store.add_log(entry)
        self.store.save()
        try:
            self.socketio.emit("irrigation_log", entry)
        except Exception:
            pass
