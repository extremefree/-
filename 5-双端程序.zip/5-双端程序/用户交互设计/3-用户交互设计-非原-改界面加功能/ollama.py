"""ollama 本地模型调用 + 关键词兜底 (从 server.py 平移)。"""
import json
import urllib.request

import config

ADVICE_POOL = [
    "今日土壤湿度适宜，可暂缓浇水。",
    "近期多雨，注意排水防涝，预防灰霉病。",
    "果实膨大期，建议追施钾肥提升糖度。",
    "午后高温，建议开启遮阳网防止日灼。",
    "监测到病害风险，建议喷施保护性杀菌剂。",
]
VALUE_POOL = [
    "当前苹果规格整齐，预计商品果率 85%+，议价能力较强。",
    "糖度检测 14.2°Brix，达优质标准，适合高端渠道。",
    "本周产区均价 6.8 元/kg，建议分批采摘错峰销售。",
    "果径 80mm 以上占比 60%，符合一级果标准。",
]


def ollama_chat(q):
    """调用本地 ollama (失败回退到 gen_reply)。"""
    payload = json.dumps({
        "model": config.OLLAMA_MODEL,
        "messages": [{"role": "user", "content": q}],
        "stream": False,
    }).encode("utf-8")
    req = urllib.request.Request(
        config.OLLAMA_URL, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            content = data.get("message", {}).get("content", "").strip()
            return content or "(空回复)"
    except Exception as e:
        print(f"[ollama] failed: {e}", flush=True)
        return f"(ollama 不可用，兜底回复) {gen_reply(q)}"


def gen_reply(q):
    q = q or ""
    if "浇水" in q:
        return "根据土壤湿度监测：当前>60% 可暂缓浇水；低于 40% 建议早晚各浇一次。"
    if "病害" in q or "白粉" in q or "锈病" in q or "灰霉" in q:
        return "常见病害建议：白粉病用醚菌酯，锈病用三唑酮，灰霉病用嘧霉胺，注意通风降湿。"
    if "价值" in q or "价格" in q:
        return "当前苹果达一级果标准，预估产值约 8-12 万元/亩，随行情波动。"
    if "天气" in q:
        return "未来三天以晴为主，午后注意高温日灼，建议开启遮阳网。"
    return "已收到您的问题，建议结合实时监测数据综合判断。"
