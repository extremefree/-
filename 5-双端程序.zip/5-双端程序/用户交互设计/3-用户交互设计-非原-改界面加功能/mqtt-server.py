"""MQTT 测试客户端 — 验证 app.py 的 MQTT 传输链路。

连接到 SIoT broker (与 app.py 同一个)，向 DFRobot/Seifer 发布各关键字上行消息，
并订阅同一主题监听 app.py 的下行指令 (水泵/施肥泵开关)。两边消息都会实时打印，
便于核对 app.py 是否正确解析上行、是否在自动模式下回出下行指令。

用法:
    python mqtt-server.py                      # 交互菜单
    python mqtt-server.py --auto               # 自动演示 (低湿度触发灌溉)
    python mqtt-server.py --host 192.168.3.48  # 指定 broker
    python mqtt-server.py --once "病害：3"      # 发一条指定消息后退出

Ctrl+C 退出。
"""
import argparse
import random
import threading
import time
import sys

import paho.mqtt.client as mqtt

# ---------- 默认配置 (与 app.py / config.py 保持一致) ----------
DEFAULT_HOST = "192.168.3.48"
DEFAULT_PORT = 1883
DEFAULT_USER = "siot"
DEFAULT_PASS = "dfrobot"
DEFAULT_TOPIC = "DFRobot/Seifer"

DISEASE_NAMES = ["白粉病", "斑褐病", "干腐病", "轮斑病", "炭疽病", "锈病"]

# 设备模拟: 水泵开启时按此流速累计水量 (mL/s)
FLOW_RATE_ML_PER_SEC = 12


def _make_client(client_id):
    """创建 paho client，兼容 1.x 与 2.x (避免 2.x 的 CallbackAPIVersion 弃用告警)。"""
    try:
        return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
    except (AttributeError, TypeError):
        return mqtt.Client(client_id=client_id)


def log(tag, msg):
    print(f"[{time.strftime('%H:%M:%S')}] {tag} {msg}", flush=True)


class MqttTester:
    def __init__(self, host, port, user, pwd, topic):
        self.topic = topic
        self.sent_count = 0
        self.recv_count = 0
        self.client = _make_client(f"apple-test-{random.randint(1000,9999)}")
        if user:
            self.client.username_pw_set(user, pwd)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.on_disconnect = self._on_disconnect
        self._host = host
        self._port = port
        self._user = user
        self._connected = threading.Event()
        # 设备模拟状态: 跟踪水泵启停 -> 上报 本次/今日 浇水量
        self.pump_start_ts = None
        self.today_water = 0

    # ---- 连接 ----
    def connect(self, timeout=10):
        log("→", f"connecting {self._host}:{self._port} user={self._user} topic={self.topic}")
        try:
            self.client.connect(self._host, self._port, keepalive=60)
        except Exception as e:
            log("✗", f"connect failed: {e}")
            log(" ", "请确认 broker 地址/网络。app.py 与本程序默认连 192.168.3.48:1883。")
            return False
        self.client.loop_start()
        return self._connected.wait(timeout=timeout)

    def _on_connect(self, client, userdata, flags, rc, properties=None):
        if rc == 0:
            self._connected.set()
            log("✓", "connected; subscribed")
            client.subscribe(self.topic)
            # 上报初始今日浇水量，让 app.py 立即有值
            self.send(f"今日浇水量：{self.today_water}")
        else:
            log("✗", f"connect rc={rc}")

    def _on_disconnect(self, client, userdata, *args, **kwargs):
        self._connected.clear()
        log("!", "disconnected (will auto-reconnect)")

    @staticmethod
    def _norm(text):
        """半角冒号规范化为全角，便于匹配下行指令。"""
        return text.replace(":", "：")

    def _on_message(self, client, userdata, msg):
        try:
            text = msg.payload.decode("utf-8")
        except Exception:
            text = repr(msg.payload)
        self.recv_count += 1
        log("← app.py", f'"{text}"')
        # 设备模拟: 监听 app.py 下行 水泵：开/关 -> 累计水量并回传
        n = self._norm(text)
        if n == "水泵：开":
            self.pump_start_ts = time.time()
            log("💧", "设备: 水泵开启，开始计量")
        elif n == "水泵：关":
            self._close_pump_cycle()

    def _close_pump_cycle(self):
        """水泵关闭: 按运行时长计算本次浇水量并累加今日总量后上报。"""
        if self.pump_start_ts is None:
            return
        duration = max(0, time.time() - self.pump_start_ts)
        volume = int(duration * FLOW_RATE_ML_PER_SEC)
        self.pump_start_ts = None
        self.today_water += volume
        log("💧", f"设备: 水泵关闭，本次 {volume}mL (运行 {duration:.1f}s)，今日累计 {self.today_water}mL")
        self.send(f"本次浇水量：{volume}")
        self.send(f"今日浇水量：{self.today_water}")

    # ---- 发布 ----
    def send(self, payload):
        info = self.client.publish(self.topic, payload)
        self.sent_count += 1
        log("→ publish", f'"{payload}"  (qos={info.qos}, mid={info.mid})')

    def close(self):
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception:
            pass


# ---------- 各关键字发送辅助 ----------
def send_moisture(t, v):       t.send(f"湿度：{v}")
def send_tank(t, v):           t.send(f"水箱水位：{v}")
def send_last_water(t, v):     t.send(f"本次浇水量：{v}")
def send_today_water(t, v):    t.send(f"今日浇水量：{v}")
def send_fruit(t, v):          t.send(f"结果数量：{v}")
def send_disease(t, idx):      t.send(f"病害：{idx}")           # 1-6
def send_disease_clear(t, idx): t.send(f"病害零：{idx}")         # 1-6


# ---------- 交互菜单 ----------
MENU = [
    ("1", "湿度：<值>",         "moisture"),
    ("2", "水箱水位：<值>",     "tank"),
    ("3", "本次浇水量：<值>",   "last_water"),
    ("4", "今日浇水量：<值>",   "today_water"),
    ("5", "结果数量：<值>",     "fruit"),
    ("6", "病害：<1-6>",        "disease"),
    ("7", "病害零：<1-6>",      "disease_clear"),
    ("a", "自动演示 60s (低湿度触发灌溉)", "auto"),
    ("s", "状态统计",           "stat"),
    ("q", "退出",               "quit"),
]

SENDERS = {
    "moisture":     ("湿度值 (0-100)", send_moisture,      lambda s: int(s)),
    "tank":         ("水箱水位 (0-100)", send_tank,        lambda s: int(s)),
    "last_water":   ("本次浇水量 mL", send_last_water,     lambda s: int(s)),
    "today_water":  ("今日浇水量 mL", send_today_water,    lambda s: int(s)),
    "fruit":        ("结果数量", send_fruit,               lambda s: int(s)),
    "disease":      (f"病害编号 1-6 ({'/'.join(DISEASE_NAMES)})", send_disease, lambda s: int(s)),
    "disease_clear":(f"清零病害编号 1-6", send_disease_clear, lambda s: int(s)),
}


def auto_demo(t, duration=60):
    """循环发送低湿度(35)触发 app.py 自动灌溉，并穿插病害/水位。"""
    log("★", f"自动演示 {duration}s — 每 4s 发一次湿度(35)，观察 app.py 下行 水泵：开")
    end = time.time() + duration
    step = 0
    while time.time() < end:
        step += 1
        send_moisture(t, 35)          # 持续低湿度 → 触发 MOISTURE_LOW=40
        if step % 5 == 0:
            send_tank(t, random.randint(60, 90))
        if step % 8 == 0:
            send_disease(t, random.randint(1, 6))
        time.sleep(4)
    log("★", "自动演示结束")


def menu_loop(t):
    while True:
        print("\n" + "=" * 52)
        print(" MQTT 测试 — 选择要发送的上行消息")
        print("=" * 52)
        for key, desc, _ in MENU:
            print(f"  [{key}] {desc}")
        choice = input("> ").strip().lower()
        if choice == "q":
            return
        if choice == "a":
            auto_demo(t)
            continue
        if choice == "s":
            log("≡", f"已发送 {t.sent_count} 条 / 已接收 {t.recv_count} 条")
            continue
        action = next((m[2] for m in MENU if m[0] == choice), None)
        if action not in SENDERS:
            print("  无效选项"); continue
        prompt, sender, conv = SENDERS[action]
        raw = input(f"  输入{prompt}: ").strip()
        try:
            val = conv(raw)
            sender(t, val)
        except ValueError:
            print("  ✗ 非法数值")


def main():
    ap = argparse.ArgumentParser(description="MQTT 测试客户端 — 验证 app.py 传输链路")
    ap.add_argument("--host", default=None, help="MQTT broker 地址 (不给则启动时交互输入)")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--user", default=DEFAULT_USER)
    ap.add_argument("--pass", dest="password", default=DEFAULT_PASS)
    ap.add_argument("--topic", default=DEFAULT_TOPIC)
    ap.add_argument("--auto", action="store_true", help="直接进入自动演示 60s")
    ap.add_argument("--once", metavar="MSG", help="只发一条指定消息后退出，如 --once '病害：3'")
    args = ap.parse_args()

    # 启动时输入 broker 地址 (未用 --host 指定时)
    host = args.host
    if host is None:
        try:
            s = input(f"请输入 MQTT broker 地址 (回车默认 {DEFAULT_HOST}): ").strip()
        except EOFError:
            s = ""
        host = s or DEFAULT_HOST

    print("=" * 56)
    print(" 苹果园水肥一体化 — MQTT 链路测试客户端 (含设备模拟)")
    print(f" broker: {host}:{args.port}  user={args.user}  topic={args.topic}")
    print(" 提示: 先确保 app.py 已启动并连上同一个 broker")
    print(" 设备模拟: 收到 水泵：开/关 会自动按流速累计并回传 本次/今日 浇水量")
    print("=" * 56)

    t = MqttTester(host, args.port, args.user, args.password, args.topic)
    if not t.connect():
        sys.exit(1)

    try:
        if args.once:
            t.send(args.once)
            time.sleep(1.5)      # 留时间观察是否有下行
        elif args.auto:
            auto_demo(t)
        else:
            menu_loop(t)
    except KeyboardInterrupt:
        print()
        log("!", "Ctrl+C 退出")
    finally:
        log("≡", f"统计: 发送 {t.sent_count} / 接收 {t.recv_count}")
        t.close()


if __name__ == "__main__":
    main()
