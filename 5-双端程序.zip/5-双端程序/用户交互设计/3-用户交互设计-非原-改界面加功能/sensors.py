"""传感器层：湿度(真实 MQTT, 超时回退仿真) + pH/EC/水箱(仿真)。

被 controller 周期性读取；也供 routes 推送前端。
"""
import random
import time

import config


class SensorHub:
    def __init__(self):
        self.moisture = config.SIM_MOISTURE_INIT
        self.ph = sum(config.SIM_PH_RANGE) / 2
        self.ec = sum(config.SIM_EC_RANGE) / 2
        self.tank = config.SIM_TANK_INIT
        self.fruit = 0
        self.last_water = 0
        self.today_water = 0
        self.moisture_real = False
        self.tank_real = False
        self.today_water_real = False
        self._last_moisture_ts = 0.0
        self._last_tank_ts = 0.0
        self._last_today_water_ts = 0.0

    # ---------- MQTT 上行入口 ----------
    def on_sensor(self, name, value):
        try:
            if name == "moisture":
                self.moisture = max(0, min(100, int(round(float(value)))))
                self.moisture_real = True
                self._last_moisture_ts = time.time()
            elif name == "tank":
                self.tank = max(0, min(100, int(round(float(value)))))
                self.tank_real = True
                self._last_tank_ts = time.time()
            elif name == "last_water":
                self.last_water = int(float(value))
            elif name == "today_water":
                # 今日浇水量由设备/MQTT 上报，服务端不再本地累计
                self.today_water = max(0, int(float(value)))
                self.today_water_real = True
                self._last_today_water_ts = time.time()
            elif name == "fruit":
                self.fruit = int(float(value))
        except (ValueError, TypeError):
            pass

    # ---------- 周期仿真 (每秒) ----------
    def tick(self):
        now = time.time()
        if self.moisture_real and (now - self._last_moisture_ts) > config.SENSOR_TIMEOUT:
            self.moisture_real = False
        if self.tank_real and (now - self._last_tank_ts) > config.SENSOR_TIMEOUT:
            self.tank_real = False
        if self.today_water_real and (now - self._last_today_water_ts) > config.SENSOR_TIMEOUT:
            self.today_water_real = False
        if not self.moisture_real:
            # 缓慢随机游走，保持在合理范围
            self.moisture = max(0, min(100, self.moisture + random.uniform(-1.0, 1.0)))
        if not self.tank_real:
            self.tank = max(0, min(100, self.tank + random.uniform(-0.2, 0.2)))
        self.ph = max(config.SIM_PH_RANGE[0], min(config.SIM_PH_RANGE[1],
                                                  self.ph + random.uniform(-0.02, 0.02)))
        self.ec = max(config.SIM_EC_RANGE[0], min(config.SIM_EC_RANGE[1],
                                                  self.ec + random.uniform(-0.02, 0.02)))

    def reset_daily(self):
        """每日 0 点或设备复位时清零今日浇水量。"""
        self.today_water = 0

    def snapshot(self):
        return {
            "moisture": round(self.moisture, 1),
            "ph": round(self.ph, 2),
            "ec": round(self.ec, 2),
            "tank": round(self.tank, 1),
            "fruit": self.fruit,
            "last_water": self.last_water,
            "today_water": self.today_water,
            "today_water_real": self.today_water_real,
            "moisture_real": self.moisture_real,
            "tank_real": self.tank_real,
        }
