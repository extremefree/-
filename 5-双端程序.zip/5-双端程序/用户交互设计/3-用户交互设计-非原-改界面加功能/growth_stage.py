"""苹果生育期 + 配方查询。"""
import datetime

import config


def resolve_stage(date=None, manual=None):
    """manual 覆盖优先；否则按月份解析。"""
    if manual and manual in config.GROWTH_RECIPES:
        return manual
    m = (date or datetime.date.today()).month
    for name, rec in config.GROWTH_RECIPES.items():
        lo, hi = rec["months"]
        if lo <= hi:
            if lo <= m <= hi:
                return name
        else:                     # 跨年段 (10..1)
            if m >= lo or m <= hi:
                return name
    return "休眠期"


def get_recipe(stage):
    return config.GROWTH_RECIPES.get(stage, config.GROWTH_RECIPES["休眠期"])


def advice_text(stage):
    """配肥指引文案 (人工按比例配 A/B 浓液)。"""
    rec = get_recipe(stage)
    npk = rec["npk"]
    if rec["volume"] == 0:
        return f"当前为【{stage}】，无需灌溉施肥。"
    return (f"当前为【{stage}】，目标 N:P:K = {npk}。"
            f"请按此比例配制 A(氮钙型) 与 B(磷钾型) 浓液："
            f"本次 A 泵运行 {rec['a_sec']}s、B 泵运行 {rec['b_sec']}s，"
            f"目标灌溉量 {rec['volume']}mL，建议频率 {rec['freq']}。")
